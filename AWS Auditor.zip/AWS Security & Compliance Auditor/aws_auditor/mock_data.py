"""
mock_data.py - Deterministic mock scan result, used when no AWS credentials
are available (e.g. portfolio demos, CI smoke tests). Clearly labeled as mock
everywhere it surfaces (CLI banner + HTML report badge) so it's never mistaken
for a live result.
"""

import datetime
from .models import Finding, ScanResult
from .compliance import controls_for


def _f(check_id, service, severity, message, detail="", resource="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def build_mock_scan_result() -> ScanResult:
    result = ScanResult(
        account_id="123456789012 (MOCK)",
        scan_time=datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z",
        regions_scanned=["us-east-1 (mock)"],
    )

    findings = [
        _f("root_mfa_disabled", "IAM", "CRITICAL", "Root account MFA is DISABLED",
           "Enable MFA on the root account immediately.", resource="root"),
        _f("root_access_keys_present", "IAM", "PASS", "No root account access keys found"),
        _f("password_policy_length", "IAM", "HIGH", "Password minimum length is 6 characters",
           "Set minimum password length to 14+."),
        _f("user_mfa_disabled", "IAM", "HIGH", "User 'deploy-bot' has no MFA device", resource="deploy-bot"),
        _f("access_key_stale", "IAM", "CRITICAL", "User 'john.smith' access key is 200 days old", resource="john.smith"),
        _f("s3_public_access", "S3", "CRITICAL", "Bucket 'dev-backup-bucket-2024' — public access not fully blocked", resource="dev-backup-bucket-2024"),
        _f("s3_encryption_disabled", "S3", "HIGH", "Bucket 'dev-backup-bucket-2024' — no default encryption", resource="dev-backup-bucket-2024"),
        _f("s3_logging_disabled", "S3", "MEDIUM", "Bucket 'analytics-raw-data' — access logging disabled", resource="analytics-raw-data"),
        _f("sg_dangerous_port_open", "EC2", "CRITICAL", "SG 'web-servers' — SSH (port 22) open to the internet", resource="sg-001", region="us-east-1 (mock)"),
        _f("sg_dangerous_port_open", "EC2", "CRITICAL", "SG 'database-layer' — MySQL (port 3306) open to the internet", resource="sg-002", region="us-east-1 (mock)"),
        _f("cloudtrail_not_configured", "CloudTrail", "CRITICAL", "No CloudTrail trail configured in us-east-1 (mock)", region="us-east-1 (mock)"),
        _f("guardduty_disabled", "GuardDuty", "HIGH", "GuardDuty is not enabled in us-east-1 (mock)", region="us-east-1 (mock)"),
    ]

    result.findings = findings
    result.total_checks = len(findings)
    return result
