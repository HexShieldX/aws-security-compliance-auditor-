"""
gui_pdf.py - PDF export for the desktop GUI.

IMPORTANT: this module does NOT recompute anything. Every number and finding
it renders comes straight from the same, unmodified functions the HTML
report and CLI already use:

    scoring.compute_risk() / scoring.compliance_score()
    report_html.SEVERITY_COLORS / report_html.RISK_COLORS / report_html.e()

Why a separate template instead of just feeding report_html.py's markup
into a PDF converter?  The pure-Python PDF renderer (xhtml2pdf, built on
reportlab) does not support CSS flexbox, CSS gradients, or non-Latin-1
glyphs such as emoji. The main HTML report intentionally uses all three
for a polished on-screen look, so passing it through unchanged looks
broken (or in some cases hangs) - which is what caused the original
"Export PDF does nothing" bug. This module renders the exact same data
using table/block markup and no emoji, so it converts to PDF reliably
while staying as visually close as possible to the HTML report (same
colors, same section order, same content).
"""

from __future__ import annotations

from .models import ScanResult
from .report_html import SEVERITY_COLORS, RISK_COLORS, e
from .scoring import compute_risk, compliance_score

PDF_PAGE_CSS = """
@page {
    size: A4;
    margin: 1.6cm;
}
* { font-family: Helvetica, Arial, sans-serif; }
body { color: #1a1a1a; font-size: 10pt; }
h1 { font-size: 18pt; color: #ffffff; margin: 0; }
h2 { font-size: 13pt; color: #1A3C5E; margin: 0 0 8px 0; }
.header-table { width: 100%; background-color: #12233a; padding: 14px; }
.header-table td { color: #ffffff; font-size: 9pt; padding: 3px 10px 3px 0; }
.section { margin-top: 16px; padding: 12px; border: 1px solid #dbe3ea; }
.risk-value { font-size: 22pt; font-weight: bold; }
.bar-outer { width: 100%; background-color: #eaeaea; }
.bar-outer td { padding: 0; height: 14px; }
table.data { width: 100%; border-collapse: collapse; font-size: 8.5pt; margin-top: 6px; }
table.data th { background-color: #1A3C5E; color: #ffffff; padding: 5px 6px; text-align: left; }
table.data td { padding: 5px 6px; border-bottom: 1px solid #eeeeee; vertical-align: top; }
.badge { color: #ffffff; padding: 2px 6px; font-size: 8pt; font-weight: bold; }
.service-row td { background-color: #1e293b; color: #ffffff; font-weight: bold; padding: 6px; }
.summary-cell { border-top: 3px solid; padding: 8px; text-align: center; }
.summary-count { font-size: 16pt; font-weight: bold; }
.summary-label { font-size: 8pt; color: #555555; }
.footer { margin-top: 18px; font-size: 8pt; color: #888888; text-align: center; }
"""


def _severity_summary_table(result: ScanResult) -> str:
    counts = result.severity_counts()
    cells = []
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "PASS", "INFO"]:
        count = counts.get(sev, 0)
        if not count:
            continue
        color = SEVERITY_COLORS.get(sev, "#6b7280")
        cells.append(
            f'<td class="summary-cell" style="border-top-color:{color};">'
            f'<div class="summary-count" style="color:{color};">{count}</div>'
            f'<div class="summary-label">{e(sev)}</div></td>'
        )
    return f'<table style="width:100%;"><tr>{"".join(cells)}</tr></table>'


def _findings_table(result: ScanResult) -> str:
    rows = []
    current_service = None
    sorted_findings = sorted(
        [f for f in result.findings if f.severity != "PASS"],
        key=lambda f: (f.service, {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}.get(f.severity, 5)),
    )
    for f in sorted_findings:
        if f.service != current_service:
            current_service = f.service
            rows.append(f'<tr class="service-row"><td colspan="4">{e(f.service)}</td></tr>')
        color = SEVERITY_COLORS.get(f.severity, "#6b7280")
        rows.append(f"""
        <tr>
            <td style="width:70px;"><span class="badge" style="background-color:{color};">{e(f.severity)}</span></td>
            <td style="width:38%;">{e(f.message)}<br/><span style="color:#666;font-size:8pt;">{e(f.detail)}</span></td>
            <td style="width:22%;color:#666;">{e(f.resource)}<br/>{e(f.region)}</td>
            <td>{e(", ".join(f.iso27001 + f.soc2 + f.nist))}</td>
        </tr>""")
    if not rows:
        return "<p>No actionable findings - all checks passed.</p>"
    return f"""
    <table class="data">
        <tr><th>Severity</th><th>Finding</th><th>Resource / Region</th><th>Controls</th></tr>
        {''.join(rows)}
    </table>"""


def _errors_section(result: ScanResult) -> str:
    if not result.errors:
        return ""
    rows = "".join(
        f'<tr><td>{e(err.get("check",""))}</td><td>{e(err.get("region","global"))}</td>'
        f'<td style="color:#dc2626;">{e(err.get("error",""))}</td></tr>'
        for err in result.errors
    )
    return f"""
    <div class="section" style="border-color:#dc2626;">
        <h2>Checks That Could Not Complete ({len(result.errors)})</h2>
        <p style="font-size:8.5pt;color:#666;">Usually caused by missing IAM permissions -
        see policies/read_only_audit_policy.json.</p>
        <table class="data">
            <tr><th>Check</th><th>Region</th><th>Error</th></tr>
            {rows}
        </table>
    </div>"""


def build_pdf_html(result: ScanResult, is_mock: bool = False, extra_section: str = "") -> str:
    """Render a PDF-renderer-safe HTML document for this scan result."""
    risk_level, risk_pct, _, _ = compute_risk(result.actionable_findings)
    score = compliance_score(result.findings)
    risk_color = RISK_COLORS.get(risk_level, "#6b7280")
    filled_width = max(1, min(100, round(risk_pct)))

    mock_note = (
        '<p style="color:#b45309;font-weight:bold;">MOCK DATA - NOT A LIVE SCAN</p>'
        if is_mock else ""
    )

    return f"""<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><style>{PDF_PAGE_CSS}</style></head>
<body>

<table class="header-table">
  <tr><td colspan="2"><h1>AWS Security &amp; Compliance Audit Report</h1></td></tr>
</table>
{mock_note}
{extra_section}
<table style="width:100%;margin-top:10px;font-size:9pt;">
  <tr>
    <td><b>Account:</b> {e(result.account_id)}</td>
    <td><b>Regions scanned:</b> {e(', '.join(result.regions_scanned) or 'n/a')}</td>
  </tr>
  <tr>
    <td><b>Scan time:</b> {e(result.scan_time)}</td>
    <td><b>Total checks:</b> {e(result.total_checks)}</td>
  </tr>
</table>

<div class="section">
  <h2>Weighted Risk Score (deterministic, not ML)</h2>
  <div class="risk-value" style="color:{risk_color};">{e(risk_level)}</div>
  <table class="bar-outer"><tr>
    <td style="width:{filled_width}%;background-color:{risk_color};"></td>
    <td></td>
  </tr></table>
  <p style="font-size:9pt;color:#555;margin-top:6px;">
    Risk score: {risk_pct:.1f}% &nbsp;|&nbsp; Compliance pass rate: {score}%<br/>
    Weighting: Critical=25pts, High=15pts, Medium=8pts, Low=3pts per finding.
  </p>
</div>

<div class="section">
  <h2>Findings Summary</h2>
  {_severity_summary_table(result)}
</div>

{_errors_section(result)}

<div class="section">
  <h2>Detailed Findings ({len(result.actionable_findings)} issues, {result.total_checks} total checks)</h2>
  {_findings_table(result)}
</div>

<div class="footer">
  Generated by AWS Security &amp; Compliance Auditor &nbsp;|&nbsp; {e(result.scan_time)}<br/>
  Frameworks referenced: ISO/IEC 27001:2022, SOC 2, NIST CSF 2.0. Not a certified audit - use to prioritize remediation.
</div>

</body>
</html>"""


def export_pdf(result: ScanResult, is_mock: bool, output_path: str, extra_section: str = "") -> str:
    """
    Render `result` straight to a PDF file at `output_path`. Raises
    RuntimeError/ImportError on failure so the caller can surface it.
    """
    from xhtml2pdf import pisa  # imported lazily so the app still runs without it

    html_content = build_pdf_html(result, is_mock=is_mock, extra_section=extra_section)
    with open(output_path, "wb") as f:
        status = pisa.CreatePDF(html_content, dest=f)
    if status.err:
        raise RuntimeError("The PDF renderer reported errors converting the report.")
    return output_path
