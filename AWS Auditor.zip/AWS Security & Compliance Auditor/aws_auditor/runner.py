"""
runner.py - Orchestrates a full scan across all regions and services.
"""

import datetime
from typing import List, Optional
import boto3

from .models import Finding, ScanResult
from .aws_client import get_caller_identity, list_enabled_regions, AuditorError
from .checks.iam_checks import run_iam_checks
from .checks.s3_checks import run_s3_checks
from .checks.ec2_checks import run_ec2_checks
from .checks.cloudtrail_checks import run_cloudtrail_checks
from .checks.guardduty_checks import run_guardduty_checks


def run_live_scan(
    home_region: str = "us-east-1",
    regions: Optional[List[str]] = None,
    progress_cb=None,
    profile_name: Optional[str] = None,
    session: Optional[boto3.Session] = None,
) -> ScanResult:
    """
    Run a real scan against the caller's AWS account.
    regions=None -> auto-discover all enabled regions.
    progress_cb, if given, is called with a short string for each step (for CLI/HTML progress).
    profile_name, if given, scans that specific AWS CLI profile
    (boto3.Session(profile_name=profile_name)) instead of the default
    session/credential chain - this is what powers multi-account scanning.
    A pre-built session can also be passed directly via `session`; if both
    are omitted this falls back to the plain default boto3.Session(),
    exactly as before.
    """
    if session is None:
        session = boto3.Session(profile_name=profile_name) if profile_name else boto3.Session()
    identity = get_caller_identity(session)  # raises AuditorError if creds missing/invalid
    account_id = identity["Account"]

    scan_time = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    result = ScanResult(account_id=account_id, scan_time=scan_time)

    def log(msg):
        if progress_cb:
            progress_cb(msg)

    # --- Global services: run once ---
    log("Running IAM checks...")
    iam_client = session.client("iam")
    findings, errors = run_iam_checks(iam_client)
    result.findings.extend(findings)
    result.errors.extend(errors)

    log("Running S3 checks...")
    s3_client = session.client("s3")
    findings, errors = run_s3_checks(s3_client)
    result.findings.extend(findings)
    result.errors.extend(errors)

    # --- Region-scoped services: loop every enabled region ---
    if regions is None:
        regions = list_enabled_regions(session, home_region=home_region)
    result.regions_scanned = regions

    for region in regions:
        log(f"Scanning region {region}...")

        ec2_client = session.client("ec2", region_name=region)
        findings, errors = run_ec2_checks(ec2_client, region)
        result.findings.extend(findings)
        result.errors.extend(errors)

        ct_client = session.client("cloudtrail", region_name=region)
        findings, errors = run_cloudtrail_checks(ct_client, region)
        result.findings.extend(findings)
        result.errors.extend(errors)

        gd_client = session.client("guardduty", region_name=region)
        findings, errors = run_guardduty_checks(gd_client, region)
        result.findings.extend(findings)
        result.errors.extend(errors)

    result.total_checks = len(result.findings)
    return result


def run_mock_scan() -> ScanResult:
    """Run against built-in mock data - no AWS credentials required. Useful for demos/CI without live access."""
    from .mock_data import build_mock_scan_result
    return build_mock_scan_result()
