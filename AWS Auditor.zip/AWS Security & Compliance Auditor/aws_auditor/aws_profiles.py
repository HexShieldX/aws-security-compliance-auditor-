"""
aws_profiles.py - Discovers configured AWS CLI profiles from the standard
~/.aws/config and ~/.aws/credentials files, so the GUI can offer true
multi-account scanning without inventing any custom configuration format.

This module only reads files - it never writes to them, and it never
creates a boto3 session itself. Session creation (boto3.Session(profile_name=...))
happens in runner.py, right where the existing scan session was already
being built.
"""

from __future__ import annotations

import configparser
import os
from typing import List


def _config_path() -> str:
    return os.path.expanduser(os.environ.get("AWS_CONFIG_FILE", "~/.aws/config"))


def _credentials_path() -> str:
    return os.path.expanduser(os.environ.get("AWS_SHARED_CREDENTIALS_FILE", "~/.aws/credentials"))


def list_aws_profiles() -> List[str]:
    """
    Returns a sorted, de-duplicated list of every AWS CLI profile name found
    in ~/.aws/config and ~/.aws/credentials.

    - In ~/.aws/config, sections are named "default" or "profile <name>".
    - In ~/.aws/credentials, sections are named directly after the profile
      (including "default").

    Returns [] if neither file exists or is readable - callers should treat
    that as "no profiles detected" and fall back to the default credential
    chain (plain boto3.Session()), exactly like the original single-account
    behavior.
    """
    profiles = set()

    config_path = _config_path()
    if os.path.isfile(config_path):
        parser = configparser.ConfigParser()
        try:
            parser.read(config_path)
            for section in parser.sections():
                name = section.strip()
                if name == "default":
                    profiles.add("default")
                elif name.startswith("profile "):
                    profiles.add(name.split("profile ", 1)[1].strip())
        except (configparser.Error, OSError):
            pass

    creds_path = _credentials_path()
    if os.path.isfile(creds_path):
        parser = configparser.ConfigParser()
        try:
            parser.read(creds_path)
            for section in parser.sections():
                name = section.strip()
                if name:
                    profiles.add(name)
        except (configparser.Error, OSError):
            pass

    return sorted(profiles)
