"""
multi_account.py - Aggregation layer for multi-account scanning.

This module does NOT scan AWS and does NOT reimplement any report
rendering. Each account is still scanned by the existing, unmodified
runner.run_live_scan(), and each account's individual report is still
written by the existing report_html.save_html_report() /
report_json.save_json_report() / gui_pdf.export_pdf().

What lives here is purely the "many accounts -> one combined view" layer:
    - AccountScanOutcome: one profile's result + timing/risk summary
    - combined_scan_result(): merges every account's findings into a single
      synthetic ScanResult so the existing scoring/report code can be reused
      unchanged to produce a combined summary
    - save_combined_html_report() / save_combined_json_report() /
      export_combined_pdf(): write combined_summary.{html,json,pdf}
"""

from __future__ import annotations

import datetime
import json
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from .models import Finding, ScanResult
from .report_html import e, generate_html_report, SEVERITY_COLORS, RISK_COLORS
from .gui_pdf import build_pdf_html
from .scoring import compute_risk, compliance_score


@dataclass
class AccountScanOutcome:
    """Result of scanning a single AWS CLI profile/account."""
    profile: str
    result: ScanResult
    risk_level: str
    risk_pct: float
    compliance_pct: int
    duration_seconds: float
    error: Optional[str] = None


def combined_scan_result(outcomes: List[AccountScanOutcome]) -> ScanResult:
    """
    Merge every account's findings/errors into one synthetic ScanResult so
    the existing scoring.py / report_html.py / gui_pdf.py functions can be
    reused as-is to render a combined, cross-account summary.
    """
    scan_time = datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"
    account_ids = [o.result.account_id for o in outcomes]
    combined = ScanResult(
        account_id=f"{len(outcomes)} accounts: " + ", ".join(account_ids),
        scan_time=scan_time,
    )

    all_regions: List[str] = []
    for outcome in outcomes:
        for f in outcome.result.findings:
            # Tag each finding with the profile/account it came from so the
            # combined findings table stays traceable to its source account.
            tagged = Finding(
                check_id=f.check_id,
                service=f.service,
                severity=f.severity,
                message=f.message,
                detail=f.detail,
                resource=f"[{outcome.profile}] {f.resource}" if f.resource else f"[{outcome.profile}]",
                resource_id=f.resource_id,
                region=f.region,
                remediation=f.remediation,
                business_risk=f.business_risk,
                iso27001=list(f.iso27001),
                soc2=list(f.soc2),
                nist=list(f.nist),
                timestamp=f.timestamp,
            )
            combined.findings.append(tagged)
        for err in outcome.result.errors:
            combined.errors.append({
                "check": f"[{outcome.profile}] {err.get('check', '')}",
                "region": err.get("region", "global"),
                "error": err.get("error", ""),
            })
        for r in outcome.result.regions_scanned:
            if r not in all_regions:
                all_regions.append(r)

    combined.regions_scanned = sorted(all_regions)
    combined.total_checks = len(combined.findings)
    return combined


def _accounts_overview_table(outcomes: List[AccountScanOutcome]) -> str:
    """A small extra card summarizing every scanned account, injected at the
    top of the combined HTML/PDF report via the extra_section hook."""
    rows = ""
    for o in outcomes:
        counts = o.result.severity_counts()
        risk_color = RISK_COLORS.get(o.risk_level, "#6b7280")
        rows += f"""
        <tr>
            <td style="font-weight:600;">{e(o.profile)}</td>
            <td>{e(o.result.account_id)}</td>
            <td><span style="background:{risk_color};color:white;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:bold;">{e(o.risk_level)}</span></td>
            <td>{o.risk_pct:.1f}%</td>
            <td>{o.compliance_pct}%</td>
            <td style="color:#dc2626;font-weight:600;">{counts.get('CRITICAL', 0)}</td>
            <td style="color:#ea580c;font-weight:600;">{counts.get('HIGH', 0)}</td>
            <td style="color:#d97706;font-weight:600;">{counts.get('MEDIUM', 0)}</td>
            <td style="color:#65a30d;font-weight:600;">{counts.get('LOW', 0)}</td>
            <td>{e(', '.join(o.result.regions_scanned) or 'n/a')}</td>
            <td>{o.duration_seconds:.1f}s</td>
        </tr>"""
    return f"""
    <div class="findings-card">
      <h2>🗂️ Accounts Scanned ({len(outcomes)})</h2>
      <table>
        <thead><tr>
          <th>Profile</th><th>Account ID</th><th>Risk Level</th><th>Risk %</th>
          <th>Compliance %</th><th>Crit</th><th>High</th><th>Med</th><th>Low</th>
          <th>Regions</th><th>Duration</th>
        </tr></thead>
        <tbody>{rows}</tbody>
      </table>
    </div>
    """


def _accounts_overview_table_pdf(outcomes: List[AccountScanOutcome]) -> str:
    """Same accounts-overview table, rendered with the plain table/block
    markup the PDF renderer (xhtml2pdf) can safely convert."""
    rows = ""
    for o in outcomes:
        counts = o.result.severity_counts()
        risk_color = RISK_COLORS.get(o.risk_level, "#6b7280")
        rows += f"""
        <tr>
            <td>{e(o.profile)}</td>
            <td>{e(o.result.account_id)}</td>
            <td><span class="badge" style="background-color:{risk_color};">{e(o.risk_level)}</span></td>
            <td>{o.risk_pct:.1f}%</td>
            <td>{o.compliance_pct}%</td>
            <td>{counts.get('CRITICAL', 0)}</td>
            <td>{counts.get('HIGH', 0)}</td>
            <td>{counts.get('MEDIUM', 0)}</td>
            <td>{counts.get('LOW', 0)}</td>
            <td>{o.duration_seconds:.1f}s</td>
        </tr>"""
    return f"""
    <div class="section">
      <h2>Accounts Scanned ({len(outcomes)})</h2>
      <table class="data">
        <tr><th>Profile</th><th>Account ID</th><th>Risk</th><th>Risk %</th>
        <th>Compliance %</th><th>Crit</th><th>High</th><th>Med</th><th>Low</th><th>Duration</th></tr>
        {rows}
      </table>
    </div>
    """


def save_combined_html_report(outcomes: List[AccountScanOutcome], output_path: str) -> str:
    combined = combined_scan_result(outcomes)
    overview = _accounts_overview_table(outcomes)
    html_out = generate_html_report(combined, is_mock=False, extra_section=overview)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_out)
    return output_path


def export_combined_pdf(outcomes: List[AccountScanOutcome], output_path: str) -> str:
    from xhtml2pdf import pisa  # imported lazily so the app still runs without it

    combined = combined_scan_result(outcomes)
    overview = _accounts_overview_table_pdf(outcomes)
    html_content = build_pdf_html(combined, is_mock=False, extra_section=overview)
    with open(output_path, "wb") as f:
        status = pisa.CreatePDF(html_content, dest=f)
    if status.err:
        raise RuntimeError("The PDF renderer reported errors converting the combined summary.")
    return output_path


def save_combined_json_report(outcomes: List[AccountScanOutcome], output_path: str) -> str:
    combined = combined_scan_result(outcomes)
    payload: Dict = {
        "scan_type": "multi_account",
        "accounts_scanned": len(outcomes),
        "accounts": [
            {
                "profile": o.profile,
                "account_id": o.result.account_id,
                "risk_level": o.risk_level,
                "risk_pct": round(o.risk_pct, 1),
                "compliance_pct": o.compliance_pct,
                "duration_seconds": round(o.duration_seconds, 1),
                "regions_scanned": o.result.regions_scanned,
                "total_checks": o.result.total_checks,
                "severity_counts": o.result.severity_counts(),
                "error": o.error,
            }
            for o in outcomes
        ],
        "combined": combined.to_dict(),
    }
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, indent=2)
    return output_path
