"""
iam_checks.py - IAM security checks. Global service, no per-region loop needed.
"""

from typing import List, Tuple
import datetime
from botocore.exceptions import ClientError
from ..models import Finding
from ..compliance import controls_for


def _f(check_id, service, severity, message, detail="", resource="", resource_id="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, resource_id=resource_id, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def run_iam_checks(iam_client) -> Tuple[List[Finding], List[dict]]:
    findings: List[Finding] = []
    errors: List[dict] = []

    # --- Root account MFA / access keys ---
    try:
        summary = iam_client.get_account_summary()["SummaryMap"]
        if summary.get("AccountMFAEnabled", 0) == 1:
            findings.append(_f("root_mfa_disabled", "IAM", "PASS", "Root account MFA is enabled"))
        else:
            findings.append(_f(
                "root_mfa_disabled", "IAM", "CRITICAL",
                "Root account MFA is DISABLED",
                "Enable MFA on the root account immediately (Console > My Security Credentials).",
                resource="root",
            ))

        if summary.get("AccountAccessKeysPresent", 0) == 0:
            findings.append(_f("root_access_keys_present", "IAM", "PASS", "No root account access keys found"))
        else:
            findings.append(_f(
                "root_access_keys_present", "IAM", "CRITICAL",
                "Root account has active access keys",
                "Delete root access keys. Use IAM roles/users for programmatic access instead.",
                resource="root",
            ))
    except ClientError as e:
        errors.append({"check": "iam_account_summary", "error": str(e)})

    # --- Password policy ---
    try:
        policy = iam_client.get_account_password_policy()["PasswordPolicy"]
        min_len = policy.get("MinimumPasswordLength", 0)
        symbols = policy.get("RequireSymbols", False)
        numbers = policy.get("RequireNumbers", False)
        max_age = policy.get("MaxPasswordAge", 999)
        reuse = policy.get("PasswordReusePrevention", 0)

        if min_len >= 14:
            findings.append(_f("password_policy_length", "IAM", "PASS", f"Password minimum length is {min_len} characters"))
        else:
            findings.append(_f(
                "password_policy_length", "IAM", "HIGH",
                f"Password minimum length is only {min_len} characters",
                "Set minimum password length to 14+.",
            ))

        if symbols and numbers:
            findings.append(_f("password_policy_complexity", "IAM", "PASS", "Password complexity requirements enabled"))
        else:
            findings.append(_f(
                "password_policy_complexity", "IAM", "MEDIUM",
                "Password complexity is not fully enforced",
                "Require uppercase, lowercase, numbers, and symbols.",
            ))

        if max_age and max_age <= 90:
            findings.append(_f("password_policy_rotation", "IAM", "PASS", f"Password rotation set to {max_age} days"))
        else:
            findings.append(_f(
                "password_policy_rotation", "IAM", "MEDIUM",
                f"Password max age is {max_age} days (too long or unset)",
                "Set password expiry to 90 days or less.",
            ))

        if reuse >= 10:
            findings.append(_f("password_policy_reuse", "IAM", "PASS", f"Password reuse prevention: last {reuse} passwords"))
        else:
            findings.append(_f(
                "password_policy_reuse", "IAM", "LOW",
                f"Password reuse prevention only covers {reuse} prior passwords",
                "Set password reuse prevention to 10 or more.",
            ))
    except iam_client.exceptions.NoSuchEntityException:
        findings.append(_f(
            "password_policy_missing", "IAM", "HIGH",
            "No account password policy is configured",
            "Create a password policy under IAM > Account settings.",
        ))
    except ClientError as e:
        errors.append({"check": "iam_password_policy", "error": str(e)})

    # --- Per-user checks, paginated ---
    try:
        paginator = iam_client.get_paginator("list_users")
        users = []
        for page in paginator.paginate():
            users.extend(page["Users"])

        findings.append(_f("iam_user_count", "IAM", "INFO", f"Total IAM users found: {len(users)}"))

        for user in users:
            username = user["UserName"]

            try:
                mfa_devices = iam_client.list_mfa_devices(UserName=username)["MFADevices"]
                if mfa_devices:
                    findings.append(_f("user_mfa_disabled", "IAM", "PASS", f"User '{username}' has MFA enabled", resource=username))
                else:
                    findings.append(_f(
                        "user_mfa_disabled", "IAM", "HIGH",
                        f"User '{username}' has no MFA device",
                        "Enable MFA for all IAM users with console access.",
                        resource=username,
                    ))
            except ClientError as e:
                errors.append({"check": f"user_mfa:{username}", "error": str(e)})

            try:
                keys = iam_client.list_access_keys(UserName=username)["AccessKeyMetadata"]
                for key in keys:
                    if key["Status"] != "Active":
                        continue
                    created = key["CreateDate"]
                    if created.tzinfo is None:
                        created = created.replace(tzinfo=datetime.timezone.utc)
                    age_days = (datetime.datetime.now(datetime.timezone.utc) - created).days
                    if age_days > 90:
                        sev = "CRITICAL" if age_days > 180 else "HIGH"
                        findings.append(_f(
                            "access_key_stale", "IAM", sev,
                            f"User '{username}' access key is {age_days} days old",
                            "Rotate access keys at least every 90 days.",
                            resource=username,
                        ))
                    else:
                        findings.append(_f("access_key_stale", "IAM", "PASS", f"User '{username}' access key age OK ({age_days}d)", resource=username))
            except ClientError as e:
                errors.append({"check": f"access_keys:{username}", "error": str(e)})

            try:
                attached_paginator = iam_client.get_paginator("list_attached_user_policies")
                for page in attached_paginator.paginate(UserName=username):
                    for policy in page["AttachedPolicies"]:
                        if "AdministratorAccess" in policy["PolicyName"]:
                            findings.append(_f(
                                "admin_policy_attached", "IAM", "HIGH",
                                f"User '{username}' has AdministratorAccess attached directly",
                                "Use IAM groups/roles with least-privilege policies instead of direct admin attachment.",
                                resource=username,
                            ))
            except ClientError as e:
                errors.append({"check": f"attached_policies:{username}", "error": str(e)})

    except ClientError as e:
        errors.append({"check": "iam_list_users", "error": str(e)})

    return findings, errors
