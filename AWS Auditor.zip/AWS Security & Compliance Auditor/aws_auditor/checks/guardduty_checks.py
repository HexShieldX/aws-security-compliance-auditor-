"""
guardduty_checks.py - GuardDuty checks. Region-scoped.
"""

from typing import List, Tuple
from botocore.exceptions import ClientError
from ..models import Finding
from ..compliance import controls_for


def _f(check_id, service, severity, message, detail="", resource="", resource_id="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, resource_id=resource_id, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def run_guardduty_checks(gd_client, region: str) -> Tuple[List[Finding], List[dict]]:
    findings: List[Finding] = []
    errors: List[dict] = []

    try:
        detector_ids = gd_client.list_detectors()["DetectorIds"]
    except ClientError as e:
        errors.append({"check": "guardduty_list_detectors", "error": str(e), "region": region})
        return findings, errors

    if not detector_ids:
        findings.append(_f(
            "guardduty_disabled", "GuardDuty", "HIGH",
            f"GuardDuty is not enabled in {region}",
            "Enable GuardDuty for continuous threat detection.",
            region=region,
        ))
        return findings, errors

    for detector_id in detector_ids:
        try:
            det = gd_client.get_detector(DetectorId=detector_id)
        except ClientError as e:
            errors.append({"check": f"guardduty_get_detector:{detector_id}", "error": str(e), "region": region})
            continue

        if det.get("Status") != "ENABLED":
            findings.append(_f(
                "guardduty_disabled", "GuardDuty", "HIGH",
                f"GuardDuty detector in {region} is disabled",
                "Enable GuardDuty for continuous threat detection.",
                region=region,
            ))
            continue

        findings.append(_f("guardduty_disabled", "GuardDuty", "PASS", f"GuardDuty is enabled in {region}", region=region))

        try:
            resp = gd_client.list_findings(
                DetectorId=detector_id,
                FindingCriteria={"Criterion": {"severity": {"Gte": 7}}},
                MaxResults=50,
            )
            high_findings = resp.get("FindingIds", [])
            if high_findings:
                findings.append(_f(
                    "guardduty_active_findings", "GuardDuty", "CRITICAL",
                    f"GuardDuty has {len(high_findings)} high-severity active finding(s) in {region}",
                    "Investigate and remediate these findings immediately.",
                    region=region,
                ))
            else:
                findings.append(_f("guardduty_active_findings", "GuardDuty", "PASS", f"No high-severity GuardDuty findings in {region}", region=region))
        except ClientError as e:
            errors.append({"check": f"guardduty_list_findings:{detector_id}", "error": str(e), "region": region})

    return findings, errors
