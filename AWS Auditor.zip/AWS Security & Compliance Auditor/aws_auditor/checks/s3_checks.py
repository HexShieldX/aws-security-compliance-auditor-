"""
s3_checks.py - S3 bucket security checks. Global service (list_buckets is
not paginated by AWS itself but we still guard against future API changes
by not assuming list length).
"""

from typing import List, Tuple
from botocore.exceptions import ClientError
from ..models import Finding
from ..compliance import controls_for


def _f(check_id, service, severity, message, detail="", resource="", resource_id="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, resource_id=resource_id, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def run_s3_checks(s3_client) -> Tuple[List[Finding], List[dict]]:
    findings: List[Finding] = []
    errors: List[dict] = []

    try:
        buckets = s3_client.list_buckets().get("Buckets", [])
    except ClientError as e:
        errors.append({"check": "s3_list_buckets", "error": str(e)})
        return findings, errors

    findings.append(_f("s3_bucket_count", "S3", "INFO", f"Total S3 buckets found: {len(buckets)}"))

    for bucket in buckets:
        name = bucket["Name"]

        # Public access block
        try:
            pab = s3_client.get_public_access_block(Bucket=name)["PublicAccessBlockConfiguration"]
            blocked = all([
                pab.get("BlockPublicAcls", False),
                pab.get("IgnorePublicAcls", False),
                pab.get("BlockPublicPolicy", False),
                pab.get("RestrictPublicBuckets", False),
            ])
            if blocked:
                findings.append(_f("s3_public_access", "S3", "PASS", f"Bucket '{name}' — public access fully blocked", resource=name))
            else:
                findings.append(_f(
                    "s3_public_access", "S3", "CRITICAL",
                    f"Bucket '{name}' — public access is not fully blocked",
                    "Enable all four public-access-block settings.",
                    resource=name,
                ))
        except ClientError as e:
            if "NoSuchPublicAccessBlockConfiguration" in str(e):
                findings.append(_f(
                    "s3_public_access", "S3", "CRITICAL",
                    f"Bucket '{name}' — no public access block configured",
                    "Configure public access block immediately.",
                    resource=name,
                ))
            else:
                errors.append({"check": f"s3_pab:{name}", "error": str(e)})

        # Encryption
        try:
            enc = s3_client.get_bucket_encryption(Bucket=name)
            rules = enc["ServerSideEncryptionConfiguration"]["Rules"]
            enc_type = rules[0]["ApplyServerSideEncryptionByDefault"]["SSEAlgorithm"]
            findings.append(_f("s3_encryption_disabled", "S3", "PASS", f"Bucket '{name}' — encrypted ({enc_type})", resource=name))
        except ClientError as e:
            if "ServerSideEncryptionConfigurationNotFoundError" in str(e):
                findings.append(_f(
                    "s3_encryption_disabled", "S3", "HIGH",
                    f"Bucket '{name}' — no default encryption configured",
                    "Enable default encryption (SSE-S3 or SSE-KMS).",
                    resource=name,
                ))
            else:
                errors.append({"check": f"s3_encryption:{name}", "error": str(e)})

        # Versioning
        try:
            ver = s3_client.get_bucket_versioning(Bucket=name)
            if ver.get("Status") == "Enabled":
                findings.append(_f("s3_versioning_disabled", "S3", "PASS", f"Bucket '{name}' — versioning enabled", resource=name))
            else:
                findings.append(_f(
                    "s3_versioning_disabled", "S3", "LOW",
                    f"Bucket '{name}' — versioning disabled",
                    "Enable versioning for recovery from accidental deletion/ransomware.",
                    resource=name,
                ))
        except ClientError as e:
            errors.append({"check": f"s3_versioning:{name}", "error": str(e)})

        # Logging
        try:
            log = s3_client.get_bucket_logging(Bucket=name)
            if "LoggingEnabled" in log:
                findings.append(_f("s3_logging_disabled", "S3", "PASS", f"Bucket '{name}' — access logging enabled", resource=name))
            else:
                findings.append(_f(
                    "s3_logging_disabled", "S3", "MEDIUM",
                    f"Bucket '{name}' — access logging disabled",
                    "Enable server access logging to a dedicated bucket.",
                    resource=name,
                ))
        except ClientError as e:
            errors.append({"check": f"s3_logging:{name}", "error": str(e)})

    return findings, errors
