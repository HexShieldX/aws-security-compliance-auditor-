"""
cloudtrail_checks.py - CloudTrail checks. Region-scoped.
"""

from typing import List, Tuple
from botocore.exceptions import ClientError
from ..models import Finding
from ..compliance import controls_for


def _f(check_id, service, severity, message, detail="", resource="", resource_id="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, resource_id=resource_id, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def run_cloudtrail_checks(ct_client, region: str) -> Tuple[List[Finding], List[dict]]:
    findings: List[Finding] = []
    errors: List[dict] = []

    try:
        trails = ct_client.describe_trails(includeShadowTrails=False)["trailList"]
    except ClientError as e:
        errors.append({"check": "cloudtrail_describe_trails", "error": str(e), "region": region})
        return findings, errors

    if not trails:
        findings.append(_f(
            "cloudtrail_not_configured", "CloudTrail", "CRITICAL",
            f"No CloudTrail trail configured in {region}",
            "Enable CloudTrail — required for incident response and most compliance frameworks.",
            region=region,
        ))
        return findings, errors

    for trail in trails:
        name = trail.get("Name", "unknown")
        multi_region = trail.get("IsMultiRegionTrail", False)
        log_validation = trail.get("LogFileValidationEnabled", False)

        if multi_region:
            findings.append(_f("cloudtrail_single_region", "CloudTrail", "PASS", f"Trail '{name}' is multi-region", region=region))
        else:
            findings.append(_f(
                "cloudtrail_single_region", "CloudTrail", "MEDIUM",
                f"Trail '{name}' is single-region only",
                "Enable multi-region trail to capture all account API activity.",
                resource=name, region=region,
            ))

        if log_validation:
            findings.append(_f("cloudtrail_validation_disabled", "CloudTrail", "PASS", f"Trail '{name}' log file validation enabled", region=region))
        else:
            findings.append(_f(
                "cloudtrail_validation_disabled", "CloudTrail", "MEDIUM",
                f"Trail '{name}' log file validation disabled",
                "Enable log file validation to detect tampering.",
                resource=name, region=region,
            ))

        try:
            status = ct_client.get_trail_status(Name=trail["TrailARN"])
            if status.get("IsLogging", False):
                findings.append(_f("cloudtrail_not_logging", "CloudTrail", "PASS", f"Trail '{name}' is actively logging", region=region))
            else:
                findings.append(_f(
                    "cloudtrail_not_logging", "CloudTrail", "CRITICAL",
                    f"Trail '{name}' logging is STOPPED",
                    "Start CloudTrail logging immediately.",
                    resource=name, region=region,
                ))
        except ClientError as e:
            errors.append({"check": f"cloudtrail_status:{name}", "error": str(e), "region": region})

    return findings, errors
