"""
ec2_checks.py - Security group checks. Region-scoped: call once per region
with a region-bound client (see runner.py).
"""

from typing import List, Tuple
from botocore.exceptions import ClientError
from ..models import Finding
from ..compliance import controls_for

DANGEROUS_PORTS = {
    22: "SSH", 3389: "RDP", 3306: "MySQL", 5432: "PostgreSQL",
    27017: "MongoDB", 6379: "Redis", 9200: "Elasticsearch",
    23: "Telnet", 21: "FTP", 445: "SMB",
}


def _f(check_id, service, severity, message, detail="", resource="", resource_id="", region="global"):
    ctrl = controls_for(check_id)
    return Finding(
        check_id=check_id, service=service, severity=severity, message=message,
        detail=detail, resource=resource, resource_id=resource_id, region=region,
        iso27001=ctrl["iso27001"], soc2=ctrl["soc2"], nist=ctrl["nist"],
    )


def run_ec2_checks(ec2_client, region: str) -> Tuple[List[Finding], List[dict]]:
    findings: List[Finding] = []
    errors: List[dict] = []

    try:
        paginator = ec2_client.get_paginator("describe_security_groups")
        sgs = []
        for page in paginator.paginate():
            sgs.extend(page["SecurityGroups"])
    except ClientError as e:
        errors.append({"check": "ec2_describe_security_groups", "error": str(e), "region": region})
        return findings, errors

    findings.append(_f("sg_count", "EC2", "INFO", f"Security groups found in {region}: {len(sgs)}", region=region))

    for sg in sgs:
        sg_id = sg["GroupId"]
        sg_name = sg.get("GroupName", "unnamed")

        for rule in sg.get("IpPermissions", []):
            from_port = rule.get("FromPort", 0)
            to_port = rule.get("ToPort", 65535)
            protocol = rule.get("IpProtocol", "-1")

            open_v4 = any(r.get("CidrIp") == "0.0.0.0/0" for r in rule.get("IpRanges", []))
            open_v6 = any(r.get("CidrIpv6") == "::/0" for r in rule.get("Ipv6Ranges", []))
            if not (open_v4 or open_v6):
                continue

            if protocol == "-1":
                findings.append(_f(
                    "sg_all_traffic_open", "EC2", "CRITICAL",
                    f"SG '{sg_name}' ({sg_id}) allows ALL traffic from 0.0.0.0/0",
                    "Remove the allow-all rule; scope inbound rules to specific ports/sources.",
                    resource=sg_id, region=region,
                ))
                continue

            hit_dangerous = False
            for port, svc in DANGEROUS_PORTS.items():
                if from_port <= port <= to_port:
                    hit_dangerous = True
                    findings.append(_f(
                        "sg_dangerous_port_open", "EC2", "CRITICAL",
                        f"SG '{sg_name}' — {svc} (port {port}) open to the internet",
                        f"Restrict port {port} to specific IP ranges or use SSM Session Manager / a bastion / VPN.",
                        resource=sg_id, region=region,
                    ))

            if not hit_dangerous:
                if from_port in (80, 443):
                    findings.append(_f("sg_web_port_open", "EC2", "INFO", f"SG '{sg_name}' — HTTP/HTTPS open (expected for public web)", resource=sg_id, region=region))
                else:
                    findings.append(_f(
                        "sg_port_open_review", "EC2", "MEDIUM",
                        f"SG '{sg_name}' — port {from_port} open to 0.0.0.0/0",
                        "Review whether this port needs to be public.",
                        resource=sg_id, region=region,
                    ))

    return findings, errors
