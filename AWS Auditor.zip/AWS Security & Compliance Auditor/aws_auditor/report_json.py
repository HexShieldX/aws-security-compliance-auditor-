"""
report_json.py - Machine-readable evidence export (for CI pipelines, SIEM ingestion, etc).
"""

import json
from .models import ScanResult


def save_json_report(result: ScanResult, output_path: str) -> str:
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(result.to_dict(), f, indent=2)
    return output_path
