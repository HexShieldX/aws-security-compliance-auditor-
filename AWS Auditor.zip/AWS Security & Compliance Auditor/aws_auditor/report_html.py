"""
report_html.py - Generates the human-readable HTML audit report.
All dynamic strings are HTML-escaped before interpolation - resource names,
IAM usernames, and SG names come from AWS API responses, which are not
inherently trusted input.
"""

import html
from typing import Dict
from .models import ScanResult
from .scoring import compute_risk, compliance_score

SEVERITY_COLORS = {
    "CRITICAL": "#dc2626", "HIGH": "#ea580c", "MEDIUM": "#d97706",
    "LOW": "#65a30d", "PASS": "#16a34a", "INFO": "#0284c7",
}

RISK_COLORS = {
    "CRITICAL RISK": "#dc2626", "HIGH RISK": "#ea580c", "MEDIUM RISK": "#d97706",
    "LOW RISK": "#65a30d", "MINIMAL RISK": "#16a34a", "UNKNOWN": "#6b7280",
}


def e(value) -> str:
    """Shorthand HTML-escape for anything interpolated into markup."""
    return html.escape(str(value), quote=True)


def generate_html_report(result: ScanResult, is_mock: bool = False, extra_section: str = "") -> str:
    risk_level, risk_pct, _, _ = compute_risk(result.actionable_findings)
    score = compliance_score(result.findings)
    counts = result.severity_counts()
    risk_color = RISK_COLORS.get(risk_level, "#6b7280")

    mock_badge = (
        '<span style="background:#f59e0b;color:white;padding:3px 10px;'
        'border-radius:12px;font-size:12px;font-weight:700;margin-left:10px;">'
        'MOCK DATA — NOT A LIVE SCAN</span>'
    ) if is_mock else ""

    summary_badges = ""
    for sev in ["CRITICAL", "HIGH", "MEDIUM", "LOW", "PASS", "INFO"]:
        count = counts.get(sev, 0)
        if count:
            color = SEVERITY_COLORS[sev]
            summary_badges += (
                f'<div style="text-align:center;padding:16px 20px;background:white;'
                f'border-radius:10px;border-top:4px solid {color};min-width:90px;">'
                f'<div style="font-size:28px;font-weight:bold;color:{color};">{count}</div>'
                f'<div style="font-size:12px;color:#666;margin-top:4px;">{e(sev)}</div></div>'
            )

    findings_rows = ""
    current_service = None
    sorted_findings = sorted(
        [f for f in result.findings if f.severity != "PASS"],
        key=lambda f: (f.service, {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3, "INFO": 4}.get(f.severity, 5)),
    )
    for f in sorted_findings:
        if f.service != current_service:
            current_service = f.service
            findings_rows += (
                f'<tr><td colspan="5" style="background:#1e293b;color:white;padding:10px 16px;'
                f'font-weight:bold;font-size:14px;">{e(f.service)}</td></tr>'
            )
        color = SEVERITY_COLORS.get(f.severity, "#6b7280")
        controls = " ".join(f'<span class="tag">{e(c)}</span>' for c in (f.iso27001 + f.soc2 + f.nist))
        findings_rows += f"""
        <tr>
            <td><span style="background:{color};color:white;padding:3px 10px;border-radius:12px;font-size:12px;font-weight:bold;">{e(f.severity)}</span></td>
            <td style="font-weight:500;">{e(f.message)}</td>
            <td style="color:#666;font-size:13px;">{e(f.detail)}</td>
            <td style="color:#999;font-size:12px;">{e(f.resource)}<br><span style="color:#bbb;">{e(f.region)}</span></td>
            <td>{controls}</td>
        </tr>"""

    error_section = ""
    if result.errors:
        rows = "".join(
            f'<tr><td>{e(err.get("check",""))}</td><td>{e(err.get("region","global"))}</td>'
            f'<td style="color:#dc2626;">{e(err.get("error",""))}</td></tr>'
            for err in result.errors
        )
        error_section = f"""
        <div class="findings-card" style="border:2px solid #dc2626;">
            <h2>⚠️ Checks That Could Not Complete ({len(result.errors)})</h2>
            <p style="color:#666;font-size:13px;margin-bottom:12px;">
                These are surfaced explicitly rather than silently skipped. Usually caused by
                missing IAM permissions — see the read-only policy in <code>policies/read_only_audit_policy.json</code>.
            </p>
            <table>
                <thead><tr><th>Check</th><th>Region</th><th>Error</th></tr></thead>
                <tbody>{rows}</tbody>
            </table>
        </div>
        """

    html_out = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>AWS Security Audit Report — {e(result.account_id)}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #f0f4f8; color: #222; }}
  .header {{ background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 100%); color: white; padding: 40px; }}
  .header h1 {{ font-size: 26px; margin-bottom: 6px; }}
  .meta {{ display: flex; gap: 20px; margin-top: 20px; flex-wrap: wrap; }}
  .meta-item {{ background: rgba(255,255,255,0.12); padding: 8px 16px; border-radius: 6px; font-size: 13px; }}
  .container {{ max-width: 1200px; margin: 0 auto; padding: 30px 20px; }}
  .risk-card {{ background: white; border-radius: 12px; padding: 30px; margin-bottom: 24px; text-align: center; border: 3px solid {risk_color}; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }}
  .risk-level {{ font-size: 34px; font-weight: bold; color: {risk_color}; }}
  .risk-bar-bg {{ background: #eee; border-radius: 20px; height: 18px; margin: 16px 0; overflow: hidden; }}
  .risk-bar {{ height: 100%; border-radius: 20px; background: {risk_color}; width: {risk_pct:.0f}%; }}
  .summary-grid {{ display: flex; gap: 16px; flex-wrap: wrap; background: white; padding: 24px; border-radius: 12px; margin-bottom: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); }}
  .findings-card {{ background: white; border-radius: 12px; padding: 24px; box-shadow: 0 4px 20px rgba(0,0,0,0.08); margin-bottom: 24px; }}
  .findings-card h2 {{ margin-bottom: 12px; color: #1A3C5E; font-size: 18px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 14px; }}
  th {{ background: #1A3C5E; color: white; padding: 10px 14px; text-align: left; font-size: 13px; }}
  td {{ padding: 9px 14px; border-bottom: 1px solid #f0f0f0; vertical-align: top; }}
  tr:hover td {{ background: #f8fbff; }}
  .tag {{ background: #e2e8f0; color: #475569; font-size: 11px; font-weight: 600; padding: 2px 7px; border-radius: 4px; margin-right: 4px; display: inline-block; margin-bottom: 2px; }}
  .footer {{ text-align: center; padding: 28px; color: #94a3b8; font-size: 12px; }}
  code {{ background: #f1f5f9; padding: 2px 6px; border-radius: 4px; font-size: 12px; }}
</style>
</head>
<body>
<div class="header">
  <h1>🔐 AWS Security &amp; Compliance Audit Report{mock_badge}</h1>
  <div class="meta">
    <div class="meta-item">👤 Account: {e(result.account_id)}</div>
    <div class="meta-item">🌍 Regions scanned: {e(', '.join(result.regions_scanned) or 'n/a')}</div>
    <div class="meta-item">📅 Scan time: {e(result.scan_time)}</div>
    <div class="meta-item">🔍 Total checks: {e(result.total_checks)}</div>
  </div>
</div>

<div class="container">
  {extra_section}
  <div class="risk-card">
    <div style="font-size:13px;color:#666;margin-bottom:8px;">WEIGHTED RISK SCORE (deterministic, not ML)</div>
    <div class="risk-level">{e(risk_level)}</div>
    <div class="risk-bar-bg"><div class="risk-bar"></div></div>
    <div style="font-size:16px;color:#666;">Risk score: {risk_pct:.1f}% &nbsp;|&nbsp; Compliance pass rate: {score}%</div>
    <div style="margin-top:10px;font-size:12px;color:#999;">
      Weighting: Critical=25pts, High=15pts, Medium=8pts, Low=3pts per finding.
    </div>
  </div>

  <div class="findings-card">
    <h2>📊 Findings Summary</h2>
    <div class="summary-grid">{summary_badges}</div>
  </div>

  {error_section}

  <div class="findings-card">
    <h2>📋 Detailed Findings ({len([f for f in result.findings if f.severity not in ('PASS','INFO')])} issues, {len(result.findings)} total checks)</h2>
    <table>
      <thead><tr><th style="width:100px;">Severity</th><th>Finding</th><th>Detail</th><th style="width:160px;">Resource / Region</th><th style="width:150px;">Controls</th></tr></thead>
      <tbody>{findings_rows}</tbody>
    </table>
  </div>
</div>

<div class="footer">
  Generated by AWS Security &amp; Compliance Auditor &nbsp;|&nbsp; {e(result.scan_time)}<br>
  Frameworks referenced: ISO/IEC 27001:2022, SOC 2, NIST CSF 2.0. Not a certified audit — use to prioritize remediation.
</div>
</body>
</html>"""
    return html_out


def save_html_report(result: ScanResult, output_path: str, is_mock: bool = False, extra_section: str = "") -> str:
    html_out = generate_html_report(result, is_mock=is_mock, extra_section=extra_section)
    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html_out)
    return output_path
