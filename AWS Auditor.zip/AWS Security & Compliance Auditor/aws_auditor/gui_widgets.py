"""
gui_widgets.py - Small, reusable presentation widgets for the desktop GUI.

Pure UI code only: nothing here touches AWS, scanning, scoring, or reporting
logic. These widgets just render numbers/strings that gui.py hands them.
"""

from __future__ import annotations

import math
import tkinter as tk
from typing import Optional

import customtkinter as ctk


class StatCard(ctk.CTkFrame):
    """A small labeled stat tile used across the dashboard row."""

    def __init__(self, master, title: str, accent: str, icon: str = "", **kwargs):
        super().__init__(master, fg_color=kwargs.pop("fg_color", "#FFFFFF"),
                          corner_radius=12, border_width=1,
                          border_color=kwargs.pop("border_color", "#E3E8EF"), **kwargs)
        self._accent = accent

        self.top_bar = ctk.CTkFrame(self, fg_color=accent, height=4, corner_radius=2)
        self.top_bar.pack(fill="x", padx=12, pady=(12, 10))

        header = ctk.CTkFrame(self, fg_color="transparent")
        header.pack(fill="x", padx=14)

        if icon:
            ctk.CTkLabel(header, text=icon, font=ctk.CTkFont(size=14),
                         text_color=accent).pack(side="left", padx=(0, 6))

        self.title_label = ctk.CTkLabel(
            header, text=title.upper(), font=ctk.CTkFont(size=10, weight="bold"),
            text_color="#66748C", anchor="w",
        )
        self.title_label.pack(side="left", fill="x", expand=True)

        self.value_label = ctk.CTkLabel(
            self, text="—", font=ctk.CTkFont(size=21, weight="bold"),
            text_color="#1A2331", anchor="w", justify="left",
        )
        self.value_label.pack(fill="x", padx=14, pady=(4, 14))

    def set_value(self, value, color: Optional[str] = None):
        text = str(value)
        # Keep long values (account IDs, region lists) from blowing out the card
        self.value_label.configure(text=text)
        if color:
            self.value_label.configure(text_color=color)
            self.top_bar.configure(fg_color=color)
        else:
            self.top_bar.configure(fg_color=self._accent)


class RiskGauge(ctk.CTkFrame):
    """
    Semi-circular risk gauge drawn on a plain tkinter Canvas (embedded inside
    a CTkFrame so it inherits the surrounding dark theme). Purely a visual
    representation of the risk percentage / level that scoring.py already
    computes - it performs no scoring itself.
    """

    def __init__(self, master, bg_color: str = "#FFFFFF", **kwargs):
        super().__init__(master, fg_color=bg_color, corner_radius=12,
                          border_width=1, border_color="#E3E8EF", **kwargs)
        self._bg_color = bg_color

        self.canvas = tk.Canvas(
            self, width=260, height=150, bg=bg_color, highlightthickness=0,
        )
        self.canvas.pack(padx=10, pady=(14, 0))

        self.caption = ctk.CTkLabel(
            self, text="RISK SCORE", font=ctk.CTkFont(size=11, weight="bold"),
            text_color="#66748C",
        )
        self.caption.pack(pady=(4, 14))

        self._pct = 0.0
        self._color = "#7d8b9a"
        self._level_text = "NO SCAN YET"
        self._render_gauge()

    def set_risk(self, pct: float, level: str, color: str):
        self._pct = max(0.0, min(100.0, pct))
        self._level_text = level
        self._color = color
        self._render_gauge()

    def _render_gauge(self):
        c = self.canvas
        c.delete("all")
        cx, cy, r = 130, 130, 100
        track_width = 18

        # Background track (full semicircle)
        c.create_arc(
            cx - r, cy - r, cx + r, cy + r,
            start=180, extent=180, style="arc",
            outline="#E3E8EF", width=track_width,
        )

        # Filled portion proportional to risk percentage
        extent = 180 * (self._pct / 100.0)
        if extent > 0:
            c.create_arc(
                cx - r, cy - r, cx + r, cy + r,
                start=180, extent=extent, style="arc",
                outline=self._color, width=track_width,
            )

        # Tick marks at 0 / 25 / 50 / 75 / 100
        for frac in (0, 0.25, 0.5, 0.75, 1.0):
            angle = math.radians(180 - 180 * frac)
            inner = r - track_width / 2 - 4
            outer = r + track_width / 2 + 4
            x1 = cx + inner * math.cos(angle)
            y1 = cy - inner * math.sin(angle)
            x2 = cx + outer * math.cos(angle)
            y2 = cy - outer * math.sin(angle)
            c.create_line(x1, y1, x2, y2, fill="#C7D0DC", width=1)

        # Center readout
        c.create_text(
            cx, cy - 26, text=f"{self._pct:.0f}%",
            fill="#1A2331", font=("Segoe UI", 26, "bold"),
        )
        c.create_text(
            cx, cy + 2, text=self._level_text,
            fill=self._color, font=("Segoe UI", 12, "bold"),
        )


class ConsolePanel(ctk.CTkFrame):
    """Scrollable, colour-tagged console log with timestamps and auto-scroll."""

    TAG_COLORS = {
        "info": "#60A5FA",      # blue - information
        "success": "#4ADE80",  # green - success
        "warn": "#FACC15",     # yellow - warning
        "error": "#F87171",    # red - error
        "muted": "#8B98AC",
    }

    def __init__(self, master, **kwargs):
        super().__init__(master, fg_color="transparent", **kwargs)

        self.textbox = ctk.CTkTextbox(
            self, fg_color="#101826", text_color="#60A5FA",
            font=ctk.CTkFont(family="Consolas", size=12),
            corner_radius=10, border_width=1, border_color="#E3E8EF",
            wrap="word",
        )
        self.textbox.pack(fill="both", expand=True)

        for tag, color in self.TAG_COLORS.items():
            self.textbox.tag_config(tag, foreground=color)

        self._autoscroll = True

    def log(self, message: str, level: str = "info", timestamp: str = ""):
        prefix = f"[{timestamp}] " if timestamp else ""
        self.textbox.configure(state="normal")
        self.textbox.insert("end", prefix, ("muted",))
        self.textbox.insert("end", message + "\n", (level,))
        if self._autoscroll:
            self.textbox.see("end")
        self.textbox.configure(state="disabled")

    def clear(self):
        self.textbox.configure(state="normal")
        self.textbox.delete("1.0", "end")
        self.textbox.configure(state="disabled")
