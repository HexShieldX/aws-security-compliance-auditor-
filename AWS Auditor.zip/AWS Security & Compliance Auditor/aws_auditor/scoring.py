"""
scoring.py - Weighted severity risk scoring.

Note: this is a deterministic weighted-sum model, not a machine-learning model.
It's named plainly on purpose - overstating "AI" in a security tool's scoring
erodes trust with anyone who actually reads the code.
"""

from typing import List, Dict, Tuple
from .models import Finding

SEVERITY_WEIGHTS = {
    "CRITICAL": 25,
    "HIGH": 15,
    "MEDIUM": 8,
    "LOW": 3,
    "INFO": 0,
    "PASS": 0,
}

RISK_THRESHOLDS = [
    (60, "CRITICAL RISK"),
    (40, "HIGH RISK"),
    (20, "MEDIUM RISK"),
    (5, "LOW RISK"),
    (0, "MINIMAL RISK"),
]


def compute_risk(findings: List[Finding]) -> Tuple[str, float, int, int]:
    """
    Returns (risk_level, risk_pct, total_score, max_possible_score).
    max_possible_score assumes every check had been CRITICAL, giving a
    stable denominator so risk_pct is comparable across scans of different size.
    """
    total_score = sum(SEVERITY_WEIGHTS.get(f.severity, 0) for f in findings)
    max_score = len(findings) * SEVERITY_WEIGHTS["CRITICAL"] if findings else 0

    if max_score == 0:
        return "UNKNOWN", 0.0, 0, 0

    pct = min((total_score / max_score) * 100, 100)
    for threshold, label in RISK_THRESHOLDS:
        if pct >= threshold:
            return label, pct, total_score, max_score
    return "MINIMAL RISK", pct, total_score, max_score


def compliance_score(findings: List[Finding]) -> int:
    """Simple pass-rate score (0-100) for an executive-summary style number."""
    scored = [f for f in findings if f.severity != "INFO"]
    if not scored:
        return 100
    passed = sum(1 for f in scored if f.severity == "PASS")
    return round((passed / len(scored)) * 100)
