"""
compliance.py - Maps each check_id to relevant compliance framework controls.
Extend this table when adding new checks - it's the single source of truth.
"""

from typing import List, Dict

COMPLIANCE_MAP: Dict[str, Dict[str, List[str]]] = {
    "root_mfa_disabled": {
        "iso27001": ["A.9.4.2"], "soc2": ["CC6.1"], "nist": ["PR.AC-7"],
    },
    "root_access_keys_present": {
        "iso27001": ["A.9.2.3"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "password_policy_length": {
        "iso27001": ["A.9.4.3"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "password_policy_complexity": {
        "iso27001": ["A.9.4.3"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "password_policy_rotation": {
        "iso27001": ["A.9.2.4"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "password_policy_reuse": {
        "iso27001": ["A.9.4.3"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "password_policy_missing": {
        "iso27001": ["A.9.4.3"], "soc2": ["CC6.1"], "nist": ["PR.AC-1"],
    },
    "user_mfa_disabled": {
        "iso27001": ["A.9.4.2"], "soc2": ["CC6.1"], "nist": ["PR.AC-7"],
    },
    "access_key_stale": {
        "iso27001": ["A.9.2.6", "A.9.4.3"], "soc2": ["CC6.1", "CC6.2"], "nist": ["PR.AC-1"],
    },
    "admin_policy_attached": {
        "iso27001": ["A.9.2.3", "A.9.1.2"], "soc2": ["CC6.3"], "nist": ["PR.AC-4"],
    },
    "s3_public_access": {
        "iso27001": ["A.8.2.3", "A.13.1.3"], "soc2": ["CC6.1", "CC6.6"], "nist": ["PR.AC-3", "PR.DS-5"],
    },
    "s3_encryption_disabled": {
        "iso27001": ["A.10.1.1"], "soc2": ["CC6.1"], "nist": ["PR.DS-1"],
    },
    "s3_versioning_disabled": {
        "iso27001": ["A.12.3.1"], "soc2": ["A1.2"], "nist": ["PR.IP-4"],
    },
    "s3_logging_disabled": {
        "iso27001": ["A.12.4.1"], "soc2": ["CC7.2"], "nist": ["DE.CM-1", "PR.PT-1"],
    },
    "sg_dangerous_port_open": {
        "iso27001": ["A.13.1.1", "A.13.1.3"], "soc2": ["CC6.6", "CC6.7"], "nist": ["PR.AC-3", "DE.CM-1"],
    },
    "sg_all_traffic_open": {
        "iso27001": ["A.13.1.1", "A.13.1.3"], "soc2": ["CC6.6", "CC6.7"], "nist": ["PR.AC-3"],
    },
    "sg_port_open_review": {
        "iso27001": ["A.13.1.3"], "soc2": ["CC6.6"], "nist": ["PR.AC-3"],
    },
    "cloudtrail_not_configured": {
        "iso27001": ["A.12.4.1", "A.12.4.3", "A.16.1.7"], "soc2": ["CC7.2", "CC7.3"], "nist": ["DE.CM-3", "PR.PT-1", "RS.AN-1"],
    },
    "cloudtrail_not_logging": {
        "iso27001": ["A.12.4.1"], "soc2": ["CC7.2"], "nist": ["DE.CM-3"],
    },
    "cloudtrail_single_region": {
        "iso27001": ["A.12.4.1"], "soc2": ["CC7.2"], "nist": ["DE.CM-3"],
    },
    "cloudtrail_validation_disabled": {
        "iso27001": ["A.12.4.2"], "soc2": ["CC7.2"], "nist": ["PR.DS-6"],
    },
    "guardduty_disabled": {
        "iso27001": ["A.12.4.1"], "soc2": ["CC7.2"], "nist": ["DE.CM-1", "DE.AE-2"],
    },
    "guardduty_active_findings": {
        "iso27001": ["A.16.1.2"], "soc2": ["CC7.3"], "nist": ["RS.AN-1"],
    },
    "aws_config_disabled": {
        "iso27001": ["A.12.1.2"], "soc2": ["CC7.1"], "nist": ["DE.CM-1"],
    },
}


def controls_for(check_id: str) -> Dict[str, List[str]]:
    return COMPLIANCE_MAP.get(check_id, {"iso27001": [], "soc2": [], "nist": []})
