"""
cli.py - Command-line entry point.

Usage:
    python -m aws_auditor.cli                       # live scan, all enabled regions
    python -m aws_auditor.cli --region us-east-1     # live scan, single region
    python -m aws_auditor.cli --mock                 # demo mode, no AWS creds needed
    python -m aws_auditor.cli --fail-on HIGH          # exit 1 if any HIGH+ finding (for CI)
    python -m aws_auditor.cli --format json --output report.json

Default report location:
    Reports are written to <project_root>/reports/, created automatically if
    it doesn't exist, using timestamped filenames
    (aws_audit_report_YYYY-MM-DD_HHMMSS.<ext>) so repeat runs never
    overwrite each other and never depend on the current working directory
    being writable. Pass --output to write to an explicit path instead.
"""

import argparse
import datetime
import sys
from pathlib import Path

from .runner import run_live_scan, run_mock_scan
from .aws_client import AuditorError
from .report_html import save_html_report
from .report_json import save_json_report
from .scoring import compute_risk

SEVERITY_RANK = {"CRITICAL": 4, "HIGH": 3, "MEDIUM": 2, "LOW": 1, "INFO": 0, "PASS": 0}

# <project_root>/reports - project-relative (not CWD-relative), so the
# default report location is stable and predictable regardless of where the
# command is invoked from. Was previously a bare relative filename
# ("aws_audit_report.html") written into the current working directory,
# which raised PermissionError on setups where that directory isn't
# writable by the current user (e.g. an install under a protected path on
# Windows) or where the file already existed read-only/locked.
PROJECT_ROOT = Path(__file__).resolve().parent.parent
REPORTS_DIR = PROJECT_ROOT / "reports"


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="AWS Security & Compliance Auditor")
    p.add_argument("--mock", action="store_true", help="Run against built-in mock data (no AWS credentials needed)")
    p.add_argument("--region", default=None, help="Home region used to discover other enabled regions (default: us-east-1)")
    p.add_argument("--regions", default=None, help="Comma-separated list of regions to scan (skips auto-discovery)")
    p.add_argument("--format", choices=["html", "json", "both"], default="html", help="Report output format")
    p.add_argument("--output", default=None,
                   help="Output file path (default: <project_root>/reports/aws_audit_report_<timestamp>.<ext>)")
    p.add_argument("--fail-on", choices=["CRITICAL", "HIGH", "MEDIUM", "LOW"], default=None,
                   help="Exit with code 1 if any finding at or above this severity is found (for CI/CD gates)")
    p.add_argument("--quiet", action="store_true", help="Suppress progress output")
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)

    def log(msg):
        if not args.quiet:
            print(f"  → {msg}")

    if args.mock:
        print("\n📋 Running in MOCK mode — no AWS credentials required, results are simulated.\n")
        result = run_mock_scan()
        is_mock = True
    else:
        try:
            regions = args.regions.split(",") if args.regions else None
            print("\n🔌 Connecting to AWS...")
            result = run_live_scan(home_region=args.region or "us-east-1", regions=regions, progress_cb=log)
            print(f"✅ Connected. Account: {result.account_id}\n")
            is_mock = False
        except AuditorError as e:
            print(f"\n❌ {e}\n", file=sys.stderr)
            print("Tip: run with --mock to try the tool without AWS credentials.\n", file=sys.stderr)
            return 2

    risk_level, risk_pct, _, _ = compute_risk(result.actionable_findings)
    counts = result.severity_counts()

    print("═" * 60)
    print(f"  Risk level : {risk_level}  ({risk_pct:.1f}%)")
    print(f"  Regions    : {', '.join(result.regions_scanned) or 'n/a'}")
    print(f"  Findings   : CRITICAL={counts['CRITICAL']} HIGH={counts['HIGH']} "
          f"MEDIUM={counts['MEDIUM']} LOW={counts['LOW']}")
    if result.errors:
        print(f"  Warning: {len(result.errors)} check(s) could not complete (see report for details)")
    print("═" * 60 + "\n")

    # Guaranteed-writable, non-colliding default report location. Both the
    # HTML and JSON report from a single run share one timestamp.
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")

    if args.format in ("html", "both"):
        out = args.output if args.format == "html" and args.output else str(REPORTS_DIR / f"aws_audit_report_{timestamp}.html")
        save_html_report(result, out, is_mock=is_mock)
        print(f"HTML report saved: {out}")

    if args.format in ("json", "both"):
        out = args.output if args.format == "json" and args.output else str(REPORTS_DIR / f"aws_audit_report_{timestamp}.json")
        save_json_report(result, out)
        print(f"JSON report saved: {out}")

    if args.fail_on:
        threshold = SEVERITY_RANK[args.fail_on]
        offending = [f for f in result.findings if SEVERITY_RANK.get(f.severity, 0) >= threshold]
        if offending:
            print(f"\n{len(offending)} finding(s) at or above {args.fail_on} - failing build.\n")
            return 1

    return 0


if __name__ == "__main__":
    sys.exit(main())
