"""
gui.py - Desktop GUI for the AWS Security & Compliance Auditor.

This module is a presentation layer only. It does NOT reimplement any
scanning, scoring, or reporting logic - it calls straight into the
existing, unmodified modules:

    runner.py       -> run_live_scan(), run_mock_scan()
    aws_client.py   -> AuditorError, get_caller_identity(), list_enabled_regions()
    scoring.py      -> compute_risk()
    report_html.py  -> save_html_report()
    report_json.py  -> save_json_report()
    gui_pdf.py      -> export_pdf()  (renderer-safe PDF export, see that file's docstring)

Scans, and now report exports, run on background threads so the window
never freezes. All communication back to the UI thread goes through a
thread-safe queue.Queue, polled with Tkinter's own .after() loop -
Tkinter widgets must only ever be touched from the main thread, so
nothing in a worker thread calls into any CTk widget directly.

Run with:
    python -m aws_auditor.gui
or via the launcher at the project root:
    python run_gui.py
"""

from __future__ import annotations

import datetime
import os
import queue
import re
import subprocess
import sys
import threading
import time
import traceback
import webbrowser
from pathlib import Path
from typing import Optional, List

import boto3
import customtkinter as ctk
from tkinter import filedialog, messagebox

from .aws_client import AuditorError, get_caller_identity, list_enabled_regions
from .aws_profiles import list_aws_profiles
from .models import ScanResult
from .multi_account import (
    AccountScanOutcome,
    combined_scan_result,
    save_combined_html_report,
    save_combined_json_report,
    export_combined_pdf,
)
from .report_html import save_html_report, RISK_COLORS as REPORT_RISK_COLORS
from .report_json import save_json_report
from .runner import run_live_scan, run_mock_scan
from .scoring import compute_risk, compliance_score
from .gui_pdf import export_pdf
from .gui_widgets import StatCard, RiskGauge, ConsolePanel

APP_TITLE = "AWS Security & Compliance Auditor"
APP_TAGLINE = "IAM · S3 · EC2 · CloudTrail · GuardDuty  —  ISO 27001 / SOC 2 / NIST CSF mapped"

# ---------------------------------------------------------------------------
# Theme - professional modern light dashboard palette (AWS Console / Azure
# Portal inspired): light gray page background, white cards, soft borders
# standing in for shadows, rounded corners, dark readable text.
# ---------------------------------------------------------------------------
BG_MAIN = "#F5F7FA"        # page background
BG_PANEL = "#FFFFFF"       # header / control panel (white "card" surface)
BG_PANEL_ALT = "#F1F4F9"   # subtle inset panel (scope box, region picker)
BG_CARD = "#FFFFFF"        # stat cards / buttons default surface
BORDER = "#E3E8EF"         # soft border used instead of a hard shadow line
TEXT_PRIMARY = "#1A2331"   # dark, readable body text
TEXT_MUTED = "#66748C"     # muted slate for secondary text
ACCENT = "#2563EB"         # primary blue accent (also used for PDF/JSON buttons)
ACCENT_HOVER = "#1D4ED8"
ACCENT_GREEN = "#16A34A"   # Live Scan
ACCENT_GREEN_HOVER = "#128038"
ACCENT_AMBER = "#F97316"   # Mock Scan (orange)
ACCENT_AMBER_HOVER = "#D6620B"
CONSOLE_BG = "#101826"     # console keeps a dark "terminal" surface for contrast/legibility

SEVERITY_COLORS = {
    "CRITICAL": "#DC2626",   # red
    "HIGH": "#F97316",       # orange
    "MEDIUM": "#EAB308",     # yellow
    "LOW": "#16A34A",        # green
}

RISK_COLORS = dict(REPORT_RISK_COLORS)
RISK_COLORS.setdefault("UNKNOWN", TEXT_MUTED)

GRAY_BTN = "#64748B"
GRAY_BTN_HOVER = "#475569"


# Same guaranteed-writable, non-colliding report location as the CLI fix:
# <project_root>/reports/, project-relative (not CWD-relative), created
# automatically, with timestamped filenames. This replaces the two bare
# relative filenames above, which wrote into whatever directory the GUI
# happened to be launched from and could raise PermissionError there
# (same root cause as the CLI's original bug).
REPORTS_DIR = Path(__file__).resolve().parent.parent / "reports"


def _new_report_path(ext: str) -> str:
    """Returns a fresh timestamped path under REPORTS_DIR for the given
    extension ('html' or 'json'), creating the directory if needed."""
    REPORTS_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    return str(REPORTS_DIR / f"aws_audit_report_{timestamp}.{ext}")

FALLBACK_REGIONS = [
    "us-east-1", "us-east-2", "us-west-1", "us-west-2",
    "eu-west-1", "eu-west-2", "eu-central-1", "eu-north-1",
    "ap-south-1", "ap-southeast-1", "ap-southeast-2",
    "ap-northeast-1", "ap-northeast-2", "sa-east-1", "ca-central-1",
]


def _all_known_regions() -> List[str]:
    """Static region-name lookup (no network/API call, no credentials needed)."""
    try:
        regions = boto3.Session().get_available_regions("ec2")
        return sorted(regions) if regions else sorted(FALLBACK_REGIONS)
    except Exception:
        return sorted(FALLBACK_REGIONS)


class AuditorGUI(ctk.CTk):
    def __init__(self):
        super().__init__()

        self.title(APP_TITLE)
        self.geometry("1240x840")
        self.minsize(1040, 720)
        self.configure(fg_color=BG_MAIN)

        # --- State ---
        self._msg_queue: "queue.Queue[tuple]" = queue.Queue()
        self._scanning = False
        self._exporting_pdf = False
        self._progress_phase = 0.0
        self._scan_total_steps = 0
        self._scan_completed_steps = 0
        self._scan_start_time: Optional[float] = None
        self._timer_job = None

        self.last_result: Optional[ScanResult] = None
        self.last_is_mock: bool = False
        self.last_html_path: Optional[str] = None
        self.last_json_path: Optional[str] = None

        self.region_vars: dict = {}
        self.scan_mode = ctk.StringVar(value="all")

        self.profile_vars: dict = {}
        self.account_outcomes: List[AccountScanOutcome] = []
        self.reports_root: Optional[str] = None

        self._build_layout()
        self.after(100, self._poll_queue)

    # ==================================================================
    # Layout
    # ==================================================================
    def _build_layout(self):
        # Root grid: row 0 = header (fixed), row 1 = the single scrollable
        # dashboard area (control panel + body, expands to fill the window),
        # row 2 = footer (fixed). Only row 1 gets weight, so the header and
        # footer never move and the middle area is the one that scrolls.
        self.grid_columnconfigure(0, weight=1)
        self.grid_rowconfigure(1, weight=1)

        self._build_header()

        # --- Single vertical scroll container for everything between the
        # header and footer. This replaces the old fixed-height body row:
        # previously, when "Scan Selected Regions" expanded the region
        # list, the control panel grew taller and simply pushed the body
        # (stat cards / console / risk gauge) off the bottom of a
        # non-scrolling window. Now the control panel and the body both
        # live inside this one CTkScrollableFrame, so the whole dashboard
        # scrolls together and nothing can become unreachable.
        self.main_scroll = ctk.CTkScrollableFrame(
            self, fg_color=BG_MAIN, corner_radius=0,
            scrollbar_button_color=BORDER, scrollbar_button_hover_color=GRAY_BTN,
        )
        self.main_scroll.grid(row=1, column=0, sticky="nsew")
        self.main_scroll.grid_columnconfigure(0, weight=1)

        self._build_control_panel()
        self._build_body()
        self._build_footer()

    # ------------------------------------------------------------------
    def _build_header(self):
        header = ctk.CTkFrame(self, fg_color=BG_PANEL, corner_radius=0, height=85,
                               border_width=0)
        header.grid(row=0, column=0, sticky="ew")
        header.grid_propagate(False)
        header.grid_columnconfigure(0, weight=1)

        # thin hairline along the bottom edge stands in for a drop shadow
        ctk.CTkFrame(header, fg_color=BORDER, height=1, corner_radius=0).place(
            relx=0, rely=1.0, relwidth=1.0, anchor="sw"
        )

        title_box = ctk.CTkFrame(header, fg_color="transparent")
        title_box.grid(row=0, column=0, sticky="w", padx=26, pady=14)

        title_row = ctk.CTkFrame(title_box, fg_color="transparent")
        title_row.pack(anchor="w")
        ctk.CTkLabel(
            title_row, text="🛡", font=ctk.CTkFont(size=24), text_color=ACCENT,
        ).pack(side="left", padx=(0, 8))
        ctk.CTkLabel(
            title_row, text=APP_TITLE, font=ctk.CTkFont(size=21, weight="bold"),
            text_color=TEXT_PRIMARY,
        ).pack(side="left")

        ctk.CTkLabel(
            title_box, text=APP_TAGLINE, font=ctk.CTkFont(size=12), text_color=TEXT_MUTED,
        ).pack(anchor="w", pady=(3, 0))

        right_box = ctk.CTkFrame(header, fg_color="transparent")
        right_box.grid(row=0, column=1, sticky="e", padx=22)

        self.status_pill = ctk.CTkLabel(
            right_box, text="●  IDLE", font=ctk.CTkFont(size=13, weight="bold"),
            text_color=TEXT_MUTED, fg_color=BG_PANEL_ALT, corner_radius=16,
            padx=16, pady=7,
        )
        self.status_pill.pack(side="left", padx=(0, 10))

        about_btn = ctk.CTkButton(
            right_box, text="ⓘ  About", width=90, height=32, corner_radius=8,
            fg_color=BG_PANEL_ALT, hover_color=BORDER, text_color=TEXT_PRIMARY,
            border_width=1, border_color=BORDER, font=ctk.CTkFont(size=12),
            command=self._show_about,
        )
        about_btn.pack(side="left")

    # ------------------------------------------------------------------
    def _build_control_panel(self):
        # Parented to the scrollable dashboard area (not the root window)
        # so it scrolls as part of the same continuous page.
        panel = ctk.CTkFrame(self.main_scroll, fg_color=BG_PANEL, corner_radius=0)
        panel.grid(row=0, column=0, sticky="ew")
        panel.grid_columnconfigure(1, weight=1)
        self.control_panel = panel

        inner = ctk.CTkFrame(panel, fg_color="transparent")
        inner.grid(row=0, column=0, sticky="ew", padx=26, pady=16)
        inner.grid_columnconfigure(3, weight=1)

        # --- Scan buttons ---
        self.live_btn = ctk.CTkButton(
            inner, text="▶  Live Scan", command=self._on_live_scan,
            fg_color=ACCENT_GREEN, hover_color=ACCENT_GREEN_HOVER,
            text_color="#06110a", font=ctk.CTkFont(size=14, weight="bold"),
            width=168, height=44, corner_radius=9,
        )
        self.live_btn.grid(row=0, column=0, rowspan=2, padx=(0, 10), sticky="n")

        self.mock_btn = ctk.CTkButton(
            inner, text="🧪  Mock Scan", command=self._on_mock_scan,
            fg_color=ACCENT_AMBER, hover_color=ACCENT_AMBER_HOVER,
            text_color="#1a1204", font=ctk.CTkFont(size=14, weight="bold"),
            width=168, height=44, corner_radius=9,
        )
        self.mock_btn.grid(row=0, column=1, rowspan=2, padx=10, sticky="n")

        # --- Region scope selector ---
        scope_box = ctk.CTkFrame(inner, fg_color=BG_PANEL_ALT, corner_radius=9,
                                  border_width=1, border_color=BORDER)
        scope_box.grid(row=0, column=2, rowspan=2, padx=10, sticky="n")

        ctk.CTkLabel(scope_box, text="LIVE SCAN SCOPE", font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=TEXT_MUTED).pack(anchor="w", padx=12, pady=(8, 2))

        ctk.CTkRadioButton(
            scope_box, text="Scan All Regions", value="all", variable=self.scan_mode,
            command=self._on_scope_change, fg_color=ACCENT, hover_color=ACCENT_HOVER,
            font=ctk.CTkFont(size=12),
        ).pack(anchor="w", padx=12, pady=2)

        ctk.CTkRadioButton(
            scope_box, text="Scan Selected Regions", value="selected", variable=self.scan_mode,
            command=self._on_scope_change, fg_color=ACCENT, hover_color=ACCENT_HOVER,
            font=ctk.CTkFont(size=12),
        ).pack(anchor="w", padx=12, pady=(2, 10))

        # --- Status readouts: current region + elapsed timer ---
        status_box = ctk.CTkFrame(inner, fg_color="transparent")
        status_box.grid(row=0, column=3, sticky="ew", padx=(16, 0))

        self.profile_label = ctk.CTkLabel(
            status_box, text="Current profile:  —", font=ctk.CTkFont(size=13),
            text_color=TEXT_MUTED, anchor="w",
        )
        self.profile_label.pack(anchor="w", pady=(2, 4))

        self.region_label = ctk.CTkLabel(
            status_box, text="Currently scanning:  —", font=ctk.CTkFont(size=13),
            text_color=TEXT_MUTED, anchor="w",
        )
        self.region_label.pack(anchor="w", pady=(0, 4))

        self.timer_label = ctk.CTkLabel(
            status_box, text="Elapsed time:  0.0s", font=ctk.CTkFont(size=13),
            text_color=TEXT_MUTED, anchor="w",
        )
        self.timer_label.pack(anchor="w")

        # --- AWS account/profile picker (multi-account scanning) ---
        self.profile_picker = ctk.CTkFrame(panel, fg_color=BG_PANEL_ALT, corner_radius=9,
                                            border_width=1, border_color=BORDER)
        self.profile_picker.grid(row=1, column=0, sticky="ew", padx=26, pady=(0, 14))
        self._build_profile_picker(self.profile_picker)

        # --- Region picker (shown only when "Selected Regions" chosen) ---
        self.region_picker = ctk.CTkFrame(panel, fg_color=BG_PANEL_ALT, corner_radius=9,
                                           border_width=1, border_color=BORDER)
        self._build_region_picker(self.region_picker)
        # not gridded yet - shown on demand by _on_scope_change()

        # --- Progress bar ---
        self.progress_bar = ctk.CTkProgressBar(
            panel, height=8, corner_radius=4, progress_color=ACCENT, fg_color=BG_PANEL_ALT,
        )
        self.progress_bar.grid(row=3, column=0, sticky="ew", padx=26, pady=(0, 14))
        self.progress_bar.set(0)

        # --- Report action buttons ---
        actions = ctk.CTkFrame(panel, fg_color="transparent")
        actions.grid(row=4, column=0, sticky="ew", padx=26, pady=(0, 16))

        button_specs = [
            # attr, text, command, fg_color, hover_color, text_color
            ("open_html_btn", "📄  Open HTML Report", self._on_open_html,
             GRAY_BTN, GRAY_BTN_HOVER, "#FFFFFF"),
            ("pdf_btn", "⭳  Export PDF", self._on_export_pdf,
             ACCENT, ACCENT_HOVER, "#FFFFFF"),
            ("json_btn", "⭳  Export JSON", self._on_export_json,
             ACCENT, ACCENT_HOVER, "#FFFFFF"),
            ("folder_btn", "📁  Open Report Folder", self._on_open_folder,
             GRAY_BTN, GRAY_BTN_HOVER, "#FFFFFF"),
        ]
        for i, (attr, text, cmd, fg, hover, txt_color) in enumerate(button_specs):
            btn = ctk.CTkButton(
                actions, text=text, command=cmd,
                fg_color=fg, hover_color=hover, text_color=txt_color,
                border_width=0, height=38, corner_radius=8,
                font=ctk.CTkFont(size=12, weight="bold"),
                state="disabled" if attr != "folder_btn" else "normal",
            )
            btn.grid(row=0, column=i, padx=(0, 10) if i < len(button_specs) - 1 else 0, sticky="ew")
            actions.grid_columnconfigure(i, weight=1)
            setattr(self, attr, btn)

    def _build_profile_picker(self, container):
        header = ctk.CTkFrame(container, fg_color="transparent")
        header.pack(fill="x", padx=14, pady=(10, 4))
        ctk.CTkLabel(header, text="AWS ACCOUNTS (CLI PROFILES) - LEAVE EMPTY TO USE DEFAULT CREDENTIALS",
                     font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=TEXT_MUTED).pack(side="left")
        ctk.CTkButton(header, text="Refresh Profiles", width=110, height=24, corner_radius=6,
                      fg_color=BG_CARD, hover_color=BORDER, font=ctk.CTkFont(size=11),
                      command=self._refresh_profiles).pack(side="right")
        ctk.CTkButton(header, text="Select All", width=80, height=24, corner_radius=6,
                      fg_color=BG_CARD, hover_color=BORDER, font=ctk.CTkFont(size=11),
                      command=lambda: self._toggle_all_profiles(True)).pack(side="right", padx=(6, 6))
        ctk.CTkButton(header, text="Clear", width=80, height=24, corner_radius=6,
                      fg_color=BG_CARD, hover_color=BORDER, font=ctk.CTkFont(size=11),
                      command=lambda: self._toggle_all_profiles(False)).pack(side="right")

        self.profile_scroll = ctk.CTkScrollableFrame(container, fg_color="transparent", height=90)
        self.profile_scroll.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        self.profile_empty_label = ctk.CTkLabel(
            self.profile_scroll,
            text="No AWS CLI profiles detected in ~/.aws/config or ~/.aws/credentials.\n"
                 "Live Scan will use your default AWS credentials, exactly as before.",
            font=ctk.CTkFont(size=12), text_color=TEXT_MUTED, justify="left",
        )

        self._populate_profile_checkboxes()

    def _populate_profile_checkboxes(self):
        """(Re)builds the profile checkbox list, preserving any checkboxes
        that are still checked for profiles that still exist."""
        previously_checked = {p for p, var in self.profile_vars.items() if var.get()}

        for child in list(self.profile_scroll.winfo_children()):
            child.destroy()
        self.profile_vars = {}

        profiles = list_aws_profiles()
        if not profiles:
            self.profile_empty_label = ctk.CTkLabel(
                self.profile_scroll,
                text="No AWS CLI profiles detected in ~/.aws/config or ~/.aws/credentials.\n"
                     "Live Scan will use your default AWS credentials, exactly as before.",
                font=ctk.CTkFont(size=12), text_color=TEXT_MUTED, justify="left",
            )
            self.profile_empty_label.pack(anchor="w", padx=8, pady=6)
            return

        cols = 4
        for i, profile in enumerate(profiles):
            var = ctk.BooleanVar(value=(profile in previously_checked))
            self.profile_vars[profile] = var
            cb = ctk.CTkCheckBox(
                self.profile_scroll, text=profile, variable=var, fg_color=ACCENT,
                hover_color=ACCENT_HOVER, font=ctk.CTkFont(size=12),
                checkbox_width=18, checkbox_height=18,
            )
            cb.grid(row=i // cols, column=i % cols, sticky="w", padx=8, pady=4)

    def _toggle_all_profiles(self, value: bool):
        for var in self.profile_vars.values():
            var.set(value)

    def _refresh_profiles(self):
        self._populate_profile_checkboxes()
        n = len(self.profile_vars)
        self._log(f"Refreshed AWS profiles - {n} profile(s) detected.", "info")

    def _selected_profiles(self) -> List[str]:
        return sorted(p for p, var in self.profile_vars.items() if var.get())

    def _build_region_picker(self, container):
        header = ctk.CTkFrame(container, fg_color="transparent")
        header.pack(fill="x", padx=14, pady=(10, 4))
        ctk.CTkLabel(header, text="SELECT REGIONS TO SCAN", font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=TEXT_MUTED).pack(side="left")
        ctk.CTkButton(header, text="Select All", width=80, height=24, corner_radius=6,
                      fg_color=BG_CARD, hover_color=BORDER, font=ctk.CTkFont(size=11),
                      command=lambda: self._toggle_all_regions(True)).pack(side="right", padx=(6, 0))
        ctk.CTkButton(header, text="Clear", width=80, height=24, corner_radius=6,
                      fg_color=BG_CARD, hover_color=BORDER, font=ctk.CTkFont(size=11),
                      command=lambda: self._toggle_all_regions(False)).pack(side="right")

        scroll = ctk.CTkScrollableFrame(container, fg_color="transparent", height=130)
        scroll.pack(fill="both", expand=True, padx=10, pady=(0, 10))

        regions = _all_known_regions()
        cols = 4
        for i, region in enumerate(regions):
            var = ctk.BooleanVar(value=False)
            self.region_vars[region] = var
            cb = ctk.CTkCheckBox(
                scroll, text=region, variable=var, fg_color=ACCENT, hover_color=ACCENT_HOVER,
                font=ctk.CTkFont(size=12), checkbox_width=18, checkbox_height=18,
            )
            cb.grid(row=i // cols, column=i % cols, sticky="w", padx=8, pady=4)

    def _toggle_all_regions(self, value: bool):
        for var in self.region_vars.values():
            var.set(value)

    def _on_scope_change(self):
        if self.scan_mode.get() == "selected":
            self.region_picker.grid(row=2, column=0, sticky="ew", padx=26, pady=(0, 14))
        else:
            self.region_picker.grid_forget()

    # ------------------------------------------------------------------
    def _build_body(self):
        # Parented to the scrollable dashboard area, directly below the
        # control panel, so this content scrolls together with it as one
        # continuous page instead of being a separate fixed-height region.
        body = ctk.CTkFrame(self.main_scroll, fg_color=BG_MAIN, corner_radius=0)
        body.grid(row=1, column=0, sticky="nsew", padx=26, pady=16)
        body.grid_columnconfigure(0, weight=3)
        body.grid_columnconfigure(1, weight=1)
        body.grid_rowconfigure(1, weight=1)

        left = ctk.CTkFrame(body, fg_color="transparent")
        left.grid(row=0, column=0, rowspan=2, sticky="nsew", padx=(0, 16))
        left.grid_columnconfigure(0, weight=1)

        # --- Status row: scan status, current region, compliance pass % ---
        status_row = ctk.CTkFrame(left, fg_color="transparent")
        status_row.grid(row=0, column=0, sticky="ew", pady=(0, 12))
        for i in range(3):
            status_row.grid_columnconfigure(i, weight=1, uniform="statuscards")

        self.card_scan_status = StatCard(status_row, "Scan Status", TEXT_MUTED, icon="⚙")
        self.card_scan_status.grid(row=0, column=0, sticky="ew", padx=(0, 8))
        self.card_scan_status.set_value("Idle")

        self.card_current_region = StatCard(status_row, "Current Region", ACCENT, icon="📍")
        self.card_current_region.grid(row=0, column=1, sticky="ew", padx=8)
        self.card_current_region.set_value("—")

        self.card_compliance = StatCard(status_row, "Compliance Pass %", ACCENT_GREEN, icon="✅")
        self.card_compliance.grid(row=0, column=2, sticky="ew", padx=(8, 0))

        # --- Top stat cards ---
        dash = ctk.CTkFrame(left, fg_color="transparent")
        dash.grid(row=1, column=0, sticky="ew", pady=(0, 12))
        for i in range(3):
            dash.grid_columnconfigure(i, weight=1, uniform="topcards")

        self.card_account = StatCard(dash, "AWS Account ID", ACCENT, icon="👤")
        self.card_account.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        self.card_regions = StatCard(dash, "Regions Scanned", ACCENT, icon="🌍")
        self.card_regions.grid(row=0, column=1, sticky="ew", padx=8)

        self.card_duration = StatCard(dash, "Last Scan Duration", ACCENT, icon="⏱")
        self.card_duration.grid(row=0, column=2, sticky="ew", padx=(8, 0))

        # --- Severity findings row ---
        sev_row = ctk.CTkFrame(left, fg_color="transparent")
        sev_row.grid(row=2, column=0, sticky="ew", pady=(0, 12))
        for i in range(4):
            sev_row.grid_columnconfigure(i, weight=1, uniform="sevcards")

        self.card_critical = StatCard(sev_row, "Critical Findings", SEVERITY_COLORS["CRITICAL"], icon="⛔")
        self.card_critical.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        self.card_high = StatCard(sev_row, "High Findings", SEVERITY_COLORS["HIGH"], icon="⚠")
        self.card_high.grid(row=0, column=1, sticky="ew", padx=8)

        self.card_medium = StatCard(sev_row, "Medium Findings", SEVERITY_COLORS["MEDIUM"], icon="◐")
        self.card_medium.grid(row=0, column=2, sticky="ew", padx=8)

        self.card_low = StatCard(sev_row, "Low Findings", SEVERITY_COLORS["LOW"], icon="●")
        self.card_low.grid(row=0, column=3, sticky="ew", padx=(8, 0))

        # --- Totals row (Total Checks / Passed Checks) ---
        totals_row = ctk.CTkFrame(left, fg_color="transparent")
        totals_row.grid(row=3, column=0, sticky="ew", pady=(0, 12))
        for i in range(2):
            totals_row.grid_columnconfigure(i, weight=1, uniform="totalcards")

        self.card_total_checks = StatCard(totals_row, "Total Checks", ACCENT, icon="🧮")
        self.card_total_checks.grid(row=0, column=0, sticky="ew", padx=(0, 8))

        self.card_passed_checks = StatCard(totals_row, "Passed Checks", ACCENT_GREEN, icon="✔")
        self.card_passed_checks.grid(row=0, column=1, sticky="ew", padx=(8, 0))

        # --- Console ---
        console_label = ctk.CTkLabel(
            left, text="LIVE SCAN CONSOLE", font=ctk.CTkFont(size=11, weight="bold"),
            text_color=TEXT_MUTED,
        )
        console_label.grid(row=4, column=0, sticky="w", pady=(0, 6))
        left.grid_rowconfigure(5, weight=1)

        # Explicit height: previously the console filled whatever leftover
        # space was left in the fixed, non-scrolling window (via the row-1
        # weight above). Now that the dashboard scrolls and has no fixed
        # viewport height, it needs its own concrete size instead of
        # "whatever's left" - this keeps its on-screen size close to what
        # it looked like before, rather than shrinking to a sliver.
        self.console = ConsolePanel(left, height=240)
        self.console.grid(row=5, column=0, sticky="nsew")
        self.console.pack_propagate(False)
        self.console.log(
            "Ready. Choose Live Scan (real AWS account) or Mock Scan (demo data, no credentials needed).",
            "info", datetime.datetime.now().strftime("%H:%M:%S"),
        )

        # --- Right column: risk gauge + risk level card ---
        right = ctk.CTkFrame(body, fg_color="transparent")
        right.grid(row=0, column=1, rowspan=2, sticky="nsew")
        right.grid_columnconfigure(0, weight=1)

        self.risk_gauge = RiskGauge(right, bg_color=BG_CARD)
        self.risk_gauge.grid(row=0, column=0, sticky="ew", pady=(0, 12))

        self.card_risk_score = StatCard(right, "Risk Score", ACCENT, icon="📊")
        self.card_risk_score.grid(row=1, column=0, sticky="ew", pady=(0, 12))

        self.card_risk_level = StatCard(right, "Risk Level", ACCENT, icon="🎯")
        self.card_risk_level.grid(row=2, column=0, sticky="ew")

    # ------------------------------------------------------------------
    def _build_footer(self):
        # Parented to the root window (not the scroll area) so the footer
        # stays pinned at the bottom of the window, always visible,
        # regardless of scroll position.
        footer = ctk.CTkFrame(self, fg_color=BG_PANEL, corner_radius=0, height=32)
        footer.grid(row=2, column=0, sticky="ew")
        footer.grid_propagate(False)
        ctk.CTkLabel(
            footer,
            text="Deterministic weighted risk scoring · Not a certified audit · Use to prioritize remediation",
            font=ctk.CTkFont(size=10), text_color=TEXT_MUTED,
        ).pack(side="left", padx=18)

    def _show_about(self):
        top = ctk.CTkToplevel(self)
        top.title("About")
        top.geometry("460x460")
        top.configure(fg_color=BG_PANEL)
        top.resizable(False, False)
        top.transient(self)

        ctk.CTkLabel(top, text="🛡", font=ctk.CTkFont(size=32), text_color=ACCENT).pack(pady=(22, 4))
        ctk.CTkLabel(top, text=APP_TITLE, font=ctk.CTkFont(size=16, weight="bold"),
                     text_color=TEXT_PRIMARY).pack()
        ctk.CTkLabel(top, text="Version 1.0", font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=ACCENT).pack(pady=(2, 0))

        ctk.CTkLabel(
            top,
            text="A read-only security & compliance auditor for AWS accounts.\n"
                 "Checks IAM, S3, EC2 security groups, CloudTrail, and GuardDuty,\n"
                 "and maps findings to ISO 27001 / SOC 2 / NIST CSF 2.0 controls.",
            font=ctk.CTkFont(size=12), text_color=TEXT_MUTED, justify="center",
        ).pack(pady=12)

        tech_box = ctk.CTkFrame(top, fg_color=BG_PANEL_ALT, corner_radius=10,
                                 border_width=1, border_color=BORDER)
        tech_box.pack(padx=30, pady=(0, 12), fill="x")
        ctk.CTkLabel(tech_box, text="BUILT WITH", font=ctk.CTkFont(size=10, weight="bold"),
                     text_color=TEXT_MUTED).pack(anchor="w", padx=14, pady=(10, 2))
        ctk.CTkLabel(
            tech_box, text="Python  ·  boto3  ·  Tkinter / CustomTkinter",
            font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_PRIMARY,
        ).pack(anchor="w", padx=14, pady=(0, 10))

        frameworks_box = ctk.CTkFrame(top, fg_color=BG_PANEL_ALT, corner_radius=10,
                                       border_width=1, border_color=BORDER)
        frameworks_box.pack(padx=30, pady=(0, 12), fill="x")
        ctk.CTkLabel(frameworks_box, text="COMPLIANCE FRAMEWORKS MAPPED",
                     font=ctk.CTkFont(size=10, weight="bold"), text_color=TEXT_MUTED).pack(
            anchor="w", padx=14, pady=(10, 2))
        ctk.CTkLabel(
            frameworks_box, text="ISO 27001  ·  SOC 2  ·  NIST CSF",
            font=ctk.CTkFont(size=12, weight="bold"), text_color=TEXT_PRIMARY,
        ).pack(anchor="w", padx=14, pady=(0, 10))

        ctk.CTkLabel(
            top, text="Risk scoring is a deterministic weighted sum - not a machine-learning model.",
            font=ctk.CTkFont(size=11), text_color=TEXT_MUTED, wraplength=380, justify="center",
        ).pack(pady=(0, 10))

        ctk.CTkLabel(top, text="Author: Ali Haider", font=ctk.CTkFont(size=12, weight="bold"),
                     text_color=TEXT_PRIMARY).pack(pady=(0, 14))

        ctk.CTkButton(top, text="Close", command=top.destroy, width=100,
                      fg_color=ACCENT, hover_color=ACCENT_HOVER, text_color="#FFFFFF").pack(pady=6)

    # ==================================================================
    # Logging / status helpers (main-thread only)
    # ==================================================================
    def _log(self, msg: str, level: str = "info"):
        ts = datetime.datetime.now().strftime("%H:%M:%S")
        self.console.log(msg, level, ts)

    def _set_status(self, text: str, color: str = TEXT_MUTED):
        self.status_pill.configure(text=text, text_color=color)

    # ==================================================================
    # Scan lifecycle (main thread)
    # ==================================================================
    def _set_scanning_ui(self, scanning: bool):
        self._scanning = scanning
        state = "disabled" if scanning else "normal"
        self.live_btn.configure(state=state)
        self.mock_btn.configure(state=state)
        if scanning:
            self._set_status("●  SCANNING…", ACCENT)
            self._progress_phase = 0.0
            self._scan_total_steps = 0
            self._scan_completed_steps = 0
            self._scan_start_time = time.monotonic()
            self.profile_label.configure(text="Current profile:  —")
            self.region_label.configure(text="Currently scanning:  —")
            self.card_scan_status.set_value("Scanning…", color=ACCENT)
            self.card_current_region.set_value("—")
            self.card_total_checks.set_value("—")
            self.card_passed_checks.set_value("—")
            self._tick_timer()
        else:
            self._scan_start_time = None
            if self._timer_job:
                self.after_cancel(self._timer_job)
                self._timer_job = None

    def _tick_timer(self):
        if not self._scanning or self._scan_start_time is None:
            return
        elapsed = time.monotonic() - self._scan_start_time
        self.timer_label.configure(text=f"Elapsed time:  {elapsed:.1f}s")
        self._update_progress_bar()
        self._timer_job = self.after(100, self._tick_timer)

    def _update_progress_bar(self):
        if self._scan_total_steps > 0:
            frac = min(1.0, self._scan_completed_steps / self._scan_total_steps)
            self.progress_bar.set(frac)
        else:
            # Unknown step count yet (still discovering regions) - gentle bounce
            self._progress_phase = (self._progress_phase + 0.03) % 2.0
            value = self._progress_phase if self._progress_phase <= 1.0 else 2.0 - self._progress_phase
            self.progress_bar.set(value * 0.3)  # keep it modest until real progress is known

    def _selected_regions(self) -> List[str]:
        return sorted(region for region, var in self.region_vars.items() if var.get())

    def _on_live_scan(self):
        if self._scanning:
            return

        regions_override: Optional[List[str]] = None
        if self.scan_mode.get() == "selected":
            regions_override = self._selected_regions()
            if not regions_override:
                messagebox.showwarning(
                    "No Regions Selected",
                    "Choose at least one region under 'Scan Selected Regions', "
                    "or switch back to 'Scan All Regions'.",
                )
                return

        selected_profiles = self._selected_profiles()
        if selected_profiles:
            self._log(
                f"Starting LIVE multi-account scan for {len(selected_profiles)} "
                f"profile(s): {', '.join(selected_profiles)}...", "info",
            )
        else:
            self._log("Starting LIVE scan against your real AWS account...", "info")

        self._set_scanning_ui(True)
        thread = threading.Thread(
            target=self._run_live_worker, args=(regions_override, selected_profiles), daemon=True,
        )
        thread.start()

    def _on_mock_scan(self):
        if self._scanning:
            return
        self._log("Starting MOCK scan (demo data, no AWS credentials required)...", "info")
        self._set_scanning_ui(True)
        self.region_label.configure(text="Currently scanning:  mock data (no live scanning)")
        thread = threading.Thread(target=self._run_mock_worker, daemon=True)
        thread.start()

    # ------------------------------------------------------------------
    # Background workers - NO widget access happens in these methods.
    # They only ever push tuples onto self._msg_queue.
    # ------------------------------------------------------------------
    def _run_live_worker(self, regions_override: Optional[List[str]], selected_profiles: Optional[List[str]] = None):
        # ------------------------------------------------------------------
        # Legacy single-account path - byte-for-byte the same behavior as
        # before whenever no AWS profile checkboxes are selected (including
        # environments where only a single "default" profile exists and the
        # picker was never touched).
        # ------------------------------------------------------------------
        if not selected_profiles:
            def progress_cb(msg: str):
                self._msg_queue.put(("log", msg))
                self._msg_queue.put(("step",))
                m = re.match(r"^Scanning region (.+)\.\.\.$", msg)
                if m:
                    self._msg_queue.put(("region", m.group(1)))

            try:
                if regions_override is not None:
                    regions_to_scan = regions_override
                    self._msg_queue.put(("log", f"Scanning {len(regions_to_scan)} selected region(s)."))
                else:
                    self._msg_queue.put(("log", "Connecting to AWS and discovering enabled regions..."))
                    session = boto3.Session()
                    get_caller_identity(session)  # raises AuditorError early if creds are missing/invalid
                    regions_to_scan = list_enabled_regions(session, home_region="us-east-1")
                    self._msg_queue.put(("log", f"Discovered {len(regions_to_scan)} enabled region(s)."))

                total_steps = 2 + len(regions_to_scan)  # IAM + S3 (global) + one step per region
                self._msg_queue.put(("total_steps", total_steps))

                result = run_live_scan(home_region="us-east-1", regions=regions_to_scan, progress_cb=progress_cb)
                self._msg_queue.put(("done", result, False))
            except AuditorError as e:
                self._msg_queue.put(("auth_error", str(e)))
            except Exception:
                self._msg_queue.put(("error", traceback.format_exc()))
            return

        # ------------------------------------------------------------------
        # Multi-account path - one or more AWS CLI profiles selected.
        # Each account is scanned sequentially with its own
        # boto3.Session(profile_name=profile) via run_live_scan(profile_name=...).
        # ------------------------------------------------------------------
        self._msg_queue.put(("multi_begin", list(selected_profiles)))
        outcomes: List[AccountScanOutcome] = []

        for idx, profile in enumerate(selected_profiles, start=1):
            self._msg_queue.put(("profile_begin", profile, idx, len(selected_profiles)))
            self._msg_queue.put(("log", f"Scanning profile: {profile}"))
            profile_start = time.monotonic()

            def progress_cb(msg: str, _profile=profile):
                self._msg_queue.put(("log", f"[{_profile}] {msg}"))
                self._msg_queue.put(("step",))
                m = re.match(r"^Scanning region (.+)\.\.\.$", msg)
                if m:
                    self._msg_queue.put(("region", m.group(1)))

            try:
                session = boto3.Session(profile_name=profile)

                if regions_override is not None:
                    regions_to_scan = regions_override
                    self._msg_queue.put(("log", f"[{profile}] Scanning {len(regions_to_scan)} selected region(s)."))
                else:
                    self._msg_queue.put(("log", f"[{profile}] Connecting and discovering enabled regions..."))
                    get_caller_identity(session)  # raises AuditorError early if creds are missing/invalid
                    regions_to_scan = list_enabled_regions(session, home_region="us-east-1")
                    self._msg_queue.put(("log", f"[{profile}] Discovered {len(regions_to_scan)} enabled region(s)."))

                total_steps = 2 + len(regions_to_scan)
                self._msg_queue.put(("total_steps", total_steps))

                result = run_live_scan(
                    home_region="us-east-1", regions=regions_to_scan,
                    progress_cb=progress_cb, session=session,
                )
                duration = time.monotonic() - profile_start
                risk_level, risk_pct, _, _ = compute_risk(result.actionable_findings)
                pass_pct = compliance_score(result.findings)

                outcome = AccountScanOutcome(
                    profile=profile, result=result, risk_level=risk_level,
                    risk_pct=risk_pct, compliance_pct=pass_pct, duration_seconds=duration,
                )

                # Per-account reports: reports/<profile>/aws_audit_report.{html,json,pdf}
                # This reuses the existing, unmodified report writers.
                out_dir = os.path.join("reports", profile)
                html_path = os.path.join(out_dir, "aws_audit_report.html")
                json_path = os.path.join(out_dir, "aws_audit_report.json")
                pdf_path = os.path.join(out_dir, "aws_audit_report.pdf")
                try:
                    os.makedirs(out_dir, exist_ok=True)
                    save_html_report(result, html_path, is_mock=False)
                    save_json_report(result, json_path)
                    try:
                        export_pdf(result, False, pdf_path)
                    except Exception as pdf_exc:
                        pdf_path = None
                        self._msg_queue.put(("log", f"[{profile}] PDF export skipped: {pdf_exc}"))
                except Exception as report_exc:
                    self._msg_queue.put(("log", f"[{profile}] Could not write reports: {report_exc}"))

                outcomes.append(outcome)
                self._msg_queue.put(("profile_done", outcome, html_path, json_path, pdf_path))
            except AuditorError as e:
                self._msg_queue.put(("profile_error", profile, str(e)))
            except Exception:
                self._msg_queue.put(("profile_error", profile, traceback.format_exc()))

        self._msg_queue.put(("multi_done", outcomes))

    def _run_mock_worker(self):
        try:
            result = run_mock_scan()
            self._msg_queue.put(("log", "Mock findings generated across IAM, S3, EC2, CloudTrail, GuardDuty."))
            self._msg_queue.put(("total_steps", 1))
            self._msg_queue.put(("step",))
            self._msg_queue.put(("done", result, True))
        except Exception:
            self._msg_queue.put(("error", traceback.format_exc()))

    # ==================================================================
    # Queue polling (main thread) - safe place to touch widgets
    # ==================================================================
    def _poll_queue(self):
        # BUGFIX (Mock Scan hang): self.after(100, self._poll_queue) used to
        # sit *after* this try/except block instead of in a finally. The
        # except clause only caught queue.Empty, so if handling any single
        # queued item raised an unrelated exception (e.g. a widget update
        # error), that exception propagated straight out of _poll_queue and
        # the reschedule call below was never reached. Tkinter's .after()
        # loop does not reschedule itself automatically, so polling stopped
        # dead - permanently. That looked exactly like a hang: the scan
        # (mock or live) had actually already finished on the worker thread
        # and pushed its "done" message, but nothing was left running on the
        # main thread to read it, so the dashboard stayed empty, the status
        # pill stayed on "SCANNING...", and the Mock Scan / Live Scan
        # buttons stayed disabled forever - the only way out was to force
        # -close the app. Wrapping the reschedule in `finally`, and each
        # individual item dispatch in its own try/except, means one bad
        # message can never take down the whole polling loop again.
        try:
            while True:
                try:
                    item = self._msg_queue.get_nowait()
                except queue.Empty:
                    break

                kind = item[0]
                try:
                    if kind == "log":
                        self._log(item[1])
                    elif kind == "step":
                        self._scan_completed_steps += 1
                    elif kind == "total_steps":
                        self._scan_total_steps = item[1]
                        self._scan_completed_steps = 0
                    elif kind == "region":
                        self.region_label.configure(text=f"Currently scanning:  {item[1]}")
                        self.card_current_region.set_value(item[1])
                    elif kind == "done":
                        self._on_scan_done(item[1], item[2])
                    elif kind == "auth_error":
                        self._on_auth_error(item[1])
                    elif kind == "error":
                        self._on_unexpected_error(item[1])
                    elif kind == "multi_begin":
                        self._on_multi_begin(item[1])
                    elif kind == "profile_begin":
                        self._on_profile_begin(item[1], item[2], item[3])
                    elif kind == "profile_done":
                        self._on_profile_done(item[1], item[2], item[3], item[4])
                    elif kind == "profile_error":
                        self._on_profile_error(item[1], item[2])
                    elif kind == "multi_done":
                        self._on_multi_done(item[1])
                    elif kind == "pdf_done":
                        self._on_pdf_done(item[1])
                    elif kind == "pdf_missing_dep":
                        self._on_pdf_missing_dep()
                    elif kind == "pdf_error":
                        self._on_pdf_error(item[1])
                except Exception:
                    # Never let a single malformed/unexpected event kill the
                    # polling loop - log it and keep going instead of hanging.
                    self._log(
                        f"Internal error handling '{kind}' event:\n{traceback.format_exc()}",
                        "error",
                    )
                    if kind in ("done", "error", "auth_error", "multi_done"):
                        # Don't leave the UI stuck in "SCANNING..." forever
                        # if the completion handler itself failed.
                        self._set_scanning_ui(False)
        finally:
            self.after(100, self._poll_queue)

    def _update_dashboard_for_result(self, result: ScanResult, elapsed: float, account_label: Optional[str] = None):
        """Refreshes every dashboard widget (risk gauge, stat cards, severity
        counts) for a given ScanResult. Shared by the single-account flow and
        the per-account / combined-summary steps of the multi-account flow,
        so the exact same dashboard fields are always populated."""
        risk_level, risk_pct, _, _ = compute_risk(result.actionable_findings)
        pass_pct = compliance_score(result.findings)
        counts = result.severity_counts()
        risk_color = RISK_COLORS.get(risk_level, TEXT_MUTED)

        self.card_account.set_value(account_label if account_label is not None else result.account_id)
        self.card_regions.set_value(", ".join(result.regions_scanned) or "n/a")
        self.card_duration.set_value(f"{elapsed:.1f}s")
        self.card_compliance.set_value(f"{pass_pct}%")
        self.card_risk_score.set_value(f"{risk_pct:.1f}%", color=risk_color)
        self.card_risk_level.set_value(risk_level, color=risk_color)
        self.risk_gauge.set_risk(risk_pct, risk_level, risk_color)

        self.card_critical.set_value(counts.get("CRITICAL", 0), SEVERITY_COLORS["CRITICAL"])
        self.card_high.set_value(counts.get("HIGH", 0), SEVERITY_COLORS["HIGH"])
        self.card_medium.set_value(counts.get("MEDIUM", 0), SEVERITY_COLORS["MEDIUM"])
        self.card_low.set_value(counts.get("LOW", 0), SEVERITY_COLORS["LOW"])

        self.card_total_checks.set_value(result.total_checks)
        self.card_passed_checks.set_value(counts.get("PASS", 0))

        if result.errors:
            self._log(f"⚠ {len(result.errors)} check(s) could not complete "
                      "(likely missing IAM permissions) - see the report for details.", "warn")

    def _on_scan_done(self, result: ScanResult, is_mock: bool):
        elapsed = (time.monotonic() - self._scan_start_time) if self._scan_start_time else 0.0
        self._set_scanning_ui(False)
        self.progress_bar.set(1.0)
        self._set_status("●  SCAN COMPLETE", ACCENT_GREEN)
        self.region_label.configure(text="Currently scanning:  —")
        self.card_scan_status.set_value("Complete", color=ACCENT_GREEN)
        self.card_current_region.set_value("—")
        self._log(f"Scan complete. {result.total_checks} check(s) performed, "
                  f"{len(result.actionable_findings)} finding(s) requiring attention.", "success")
        self._log(f"Scan completed in {elapsed:.1f} seconds.", "success")

        self.last_result = result
        self.last_is_mock = is_mock

        self._update_dashboard_for_result(result, elapsed)

        # Auto-generate both HTML and JSON reports right away, exactly like the CLI does,
        # so every export/open action always has something fresh to work with.
        try:
            html_path = _new_report_path("html")
            save_html_report(result, html_path, is_mock=is_mock)
            self.last_html_path = os.path.abspath(html_path)
            self._log(f"HTML report saved: {self.last_html_path}", "success")
        except Exception as e:
            self._log(f"Could not auto-save HTML report: {e}", "error")

        try:
            json_path = _new_report_path("json")
            save_json_report(result, json_path)
            self.last_json_path = os.path.abspath(json_path)
            self._log(f"JSON report saved: {self.last_json_path}", "success")
        except Exception as e:
            self._log(f"Could not auto-save JSON report: {e}", "error")

        self.open_html_btn.configure(state="normal")
        self.pdf_btn.configure(state="normal")
        self.json_btn.configure(state="normal")

    # ==================================================================
    # Multi-account scan lifecycle (main thread)
    # ==================================================================
    def _on_multi_begin(self, profiles: List[str]):
        self.account_outcomes = []
        self.reports_root = os.path.abspath("reports")
        self._log(f"Multi-account scan starting for {len(profiles)} profile(s): "
                  f"{', '.join(profiles)}", "info")

    def _on_profile_begin(self, profile: str, idx: int, total: int):
        self.profile_label.configure(text=f"Current profile:  {profile}  ({idx}/{total})")
        self.region_label.configure(text="Currently scanning:  —")
        self.card_current_region.set_value("—")
        self.card_scan_status.set_value(f"Scanning {profile}…", color=ACCENT)

    def _on_profile_done(self, outcome: AccountScanOutcome, html_path: str, json_path: str,
                          pdf_path: Optional[str]):
        self.account_outcomes.append(outcome)
        self._log(
            f"[{outcome.profile}] Scan complete - {outcome.risk_level} "
            f"({outcome.risk_pct:.1f}%), {len(outcome.result.actionable_findings)} finding(s), "
            f"{outcome.duration_seconds:.1f}s.", "success",
        )
        self._log(f"[{outcome.profile}] Reports saved under: {os.path.dirname(os.path.abspath(html_path))}",
                  "success")

        # Dashboard is refreshed after every completed account, per requirement.
        self._update_dashboard_for_result(outcome.result, outcome.duration_seconds,
                                           account_label=f"{outcome.profile} ({outcome.result.account_id})")

        self.last_result = outcome.result
        self.last_is_mock = False
        self.last_html_path = os.path.abspath(html_path)
        self.last_json_path = os.path.abspath(json_path)
        self.open_html_btn.configure(state="normal")
        self.pdf_btn.configure(state="normal")
        self.json_btn.configure(state="normal")

    def _on_profile_error(self, profile: str, message: str):
        self._log(f"❌ [{profile}] Scan failed - skipping this account:", "error")
        for line in message.strip().splitlines()[-4:]:
            self._log("   " + line, "error")

    def _on_multi_done(self, outcomes: List[AccountScanOutcome]):
        self._set_scanning_ui(False)
        self.progress_bar.set(1.0)
        self.profile_label.configure(text="Current profile:  —")
        self.region_label.configure(text="Currently scanning:  —")
        self.card_current_region.set_value("—")

        if not outcomes:
            self._set_status("●  SCAN FAILED", SEVERITY_COLORS["CRITICAL"])
            self.card_scan_status.set_value("Failed", color=SEVERITY_COLORS["CRITICAL"])
            self._log("❌ None of the selected profiles could be scanned.", "error")
            messagebox.showerror(
                "Multi-Account Scan Failed",
                "None of the selected AWS profiles could be scanned. See the console log for details.",
            )
            return

        self._set_status("●  SCAN COMPLETE", ACCENT_GREEN)
        self.card_scan_status.set_value("Complete", color=ACCENT_GREEN)

        if len(outcomes) == 1:
            # A single profile was picked from the account list - its own
            # dashboard numbers (set in _on_profile_done) already stand as
            # the final result, so there's nothing further to combine.
            self._log("Scan finished for the selected account.", "success")
            return

        total_elapsed = sum(o.duration_seconds for o in outcomes)
        self._log(f"All {len(outcomes)} account scan(s) complete. Building combined summary...", "info")

        combined = combined_scan_result(outcomes)
        account_label = f"{len(outcomes)} accounts: " + ", ".join(o.profile for o in outcomes)
        self._update_dashboard_for_result(combined, total_elapsed, account_label=account_label)

        try:
            os.makedirs("reports", exist_ok=True)
            html_path = os.path.join("reports", "combined_summary.html")
            json_path = os.path.join("reports", "combined_summary.json")
            pdf_path = os.path.join("reports", "combined_summary.pdf")

            save_combined_html_report(outcomes, html_path)
            save_combined_json_report(outcomes, json_path)
            try:
                export_combined_pdf(outcomes, pdf_path)
            except Exception as pdf_exc:
                self._log(f"Combined PDF export skipped: {pdf_exc}", "warn")

            self.last_result = combined
            self.last_is_mock = False
            self.last_html_path = os.path.abspath(html_path)
            self.last_json_path = os.path.abspath(json_path)
            self._log(f"Combined summary saved: {self.last_html_path}", "success")
            self.open_html_btn.configure(state="normal")
            self.pdf_btn.configure(state="normal")
            self.json_btn.configure(state="normal")
        except Exception as e:
            self._log(f"❌ Could not build combined summary: {e}", "error")

    def _on_auth_error(self, message: str):
        self._set_scanning_ui(False)
        self._set_status("●  AUTH ERROR", SEVERITY_COLORS["CRITICAL"])
        self.region_label.configure(text="Currently scanning:  —")
        self.card_scan_status.set_value("Auth Error", color=SEVERITY_COLORS["CRITICAL"])
        self.card_current_region.set_value("—")
        self._log(f"❌ {message}", "error")
        messagebox.showerror(
            "AWS Authentication Error",
            f"{message}\n\nTip: use Mock Scan to try the tool without AWS credentials.",
        )

    def _on_unexpected_error(self, tb_text: str):
        self._set_scanning_ui(False)
        self._set_status("●  ERROR", SEVERITY_COLORS["CRITICAL"])
        self.region_label.configure(text="Currently scanning:  —")
        self.card_scan_status.set_value("Error", color=SEVERITY_COLORS["CRITICAL"])
        self.card_current_region.set_value("—")
        self._log("❌ Unexpected error during scan:", "error")
        last_line = tb_text.strip().splitlines()[-1] if tb_text.strip() else ""
        for line in tb_text.strip().splitlines()[-6:]:
            self._log("   " + line, "error")

        # Friendlier framing for the most common failure modes, without
        # touching or reinterpreting the underlying scanning/boto3 logic.
        lower = last_line.lower()
        if any(term in lower for term in ("endpointconnectionerror", "connecttimeouterror",
                                           "nameresolutionerror", "connectionerror", "network")):
            title, friendly = "No Internet Connection", (
                "The scan could not reach AWS. Please check your internet connection "
                "and try again."
            )
        elif any(term in lower for term in ("accessdenied", "unauthorizedoperation", "forbidden")):
            title, friendly = "Permission Denied", (
                "AWS denied one or more API calls. Your credentials may be missing "
                "permissions - see policies/read_only_audit_policy.json for the "
                "recommended read-only policy."
            )
        else:
            title, friendly = "Scan Failed", "An unexpected error occurred. See the console log for details."
        messagebox.showerror(title, friendly)

    # ==================================================================
    # Report actions - HTML / PDF / JSON / Folder
    # ==================================================================
    def _ensure_html_report(self) -> Optional[str]:
        """Guarantees an up-to-date HTML report exists on disk, generating
        it on the spot if missing, so callers never have to show a
        'file not found' error to the user."""
        if not self.last_result:
            messagebox.showwarning("No Scan Yet", "Run a Live Scan or Mock Scan first.")
            return None
        if not self.last_html_path or not os.path.exists(self.last_html_path):
            try:
                self._log("HTML report missing - regenerating it now...", "warn")
                html_path = _new_report_path("html")
                save_html_report(self.last_result, html_path, is_mock=self.last_is_mock)
                self.last_html_path = os.path.abspath(html_path)
                self._log(f"HTML report regenerated: {self.last_html_path}", "success")
            except Exception as e:
                messagebox.showerror("Error", f"Could not generate HTML report:\n{e}")
                return None
        return self.last_html_path

    def _ensure_json_report(self) -> Optional[str]:
        """Same guarantee as _ensure_html_report(), but for the JSON export."""
        if not self.last_result:
            messagebox.showwarning("No Scan Yet", "Run a Live Scan or Mock Scan first.")
            return None
        if not self.last_json_path or not os.path.exists(self.last_json_path):
            try:
                self._log("JSON report missing - regenerating it now...", "warn")
                json_path = _new_report_path("json")
                save_json_report(self.last_result, json_path)
                self.last_json_path = os.path.abspath(json_path)
                self._log(f"JSON report regenerated: {self.last_json_path}", "success")
            except Exception as e:
                messagebox.showerror("Error", f"Could not generate JSON report:\n{e}")
                return None
        return self.last_json_path

    def _open_with_os(self, path: str) -> bool:
        """Open a file or folder with the platform's default handler.
        Returns True on success, False if it could not be opened."""
        try:
            if sys.platform.startswith("darwin"):
                subprocess.run(["open", path], check=False)
            elif sys.platform.startswith("win"):
                os.startfile(path)  # type: ignore[attr-defined]
            else:
                subprocess.run(["xdg-open", path], check=False)
            return True
        except Exception as e:
            self._log(f"Could not open '{path}' with the OS file handler: {e}", "warn")
            return False

    def _on_open_html(self):
        path = self._ensure_html_report()
        if not path:
            return
        self._log(f"Opening HTML report: {path}", "info")
        if not self._open_with_os(path):
            self._log("Falling back to the default web browser.", "warn")
            webbrowser.open(f"file://{path}")

    def _on_export_pdf(self):
        if self._exporting_pdf:
            return
        html_path = self._ensure_html_report()
        if not html_path:
            return

        save_path = filedialog.asksaveasfilename(
            title="Export Report as PDF",
            defaultextension=".pdf",
            initialfile="aws_audit_report.pdf",
            filetypes=[("PDF file", "*.pdf")],
        )
        if not save_path:
            return

        self._exporting_pdf = True
        self.pdf_btn.configure(state="disabled", text="⏳  Exporting…")
        self._log("Generating PDF report - this runs in the background so the app stays responsive...", "info")
        thread = threading.Thread(target=self._export_pdf_worker, args=(save_path,), daemon=True)
        thread.start()

    def _export_pdf_worker(self, save_path: str):
        try:
            export_pdf(self.last_result, self.last_is_mock, save_path)
            self._msg_queue.put(("pdf_done", save_path))
        except ImportError:
            self._msg_queue.put(("pdf_missing_dep",))
        except Exception:
            self._msg_queue.put(("pdf_error", traceback.format_exc()))

    def _on_pdf_done(self, save_path: str):
        self._exporting_pdf = False
        self.pdf_btn.configure(state="normal", text="⭳  Export PDF")
        self._log(f"PDF report exported: {save_path}", "success")
        messagebox.showinfo("Export Complete", f"PDF report saved to:\n{save_path}")
        self._log(f"Opening PDF report: {save_path}", "info")
        self._open_with_os(save_path)

    def _on_pdf_missing_dep(self):
        self._exporting_pdf = False
        self.pdf_btn.configure(state="normal", text="⭳  Export PDF")
        self._log("❌ PDF export requires the 'xhtml2pdf' package, which is not installed.", "error")
        messagebox.showerror(
            "Missing Dependency",
            "PDF export requires the 'xhtml2pdf' package.\n\nInstall it with:\n    pip install xhtml2pdf\n\n"
            "Then try Export PDF again.",
        )

    def _on_pdf_error(self, tb_text: str):
        self._exporting_pdf = False
        self.pdf_btn.configure(state="normal", text="⭳  Export PDF")
        self._log("❌ PDF export failed:", "error")
        for line in tb_text.strip().splitlines()[-6:]:
            self._log("   " + line, "error")
        messagebox.showerror("Export Failed", "Could not export PDF. See the console log for details.")

    def _on_export_json(self):
        # Guarantee a JSON file exists first, per the requirement that this
        # export must never surface a "file not found" error to the user.
        if not self._ensure_json_report():
            return

        save_path = filedialog.asksaveasfilename(
            title="Export Report as JSON",
            defaultextension=".json",
            initialfile="aws_audit_report.json",
            filetypes=[("JSON file", "*.json")],
        )
        if not save_path:
            return

        try:
            save_json_report(self.last_result, save_path)
            self.last_json_path = os.path.abspath(save_path)
            self._log(f"JSON report exported: {save_path}", "success")
            messagebox.showinfo("Export Complete", f"JSON report saved to:\n{save_path}")
            # Best-effort auto-open: JSON files don't always have a registered
            # viewer/editor on every OS, so a failure here is silently non-fatal.
            self._log(f"Opening JSON report: {save_path}", "info")
            self._open_with_os(save_path)
        except Exception as e:
            self._log(f"❌ JSON export failed: {e}", "error")
            messagebox.showerror("Export Failed", f"Could not export JSON:\n{e}")

    def _on_open_folder(self):
        if self.last_html_path:
            folder = os.path.dirname(self.last_html_path)
        elif self.last_json_path:
            folder = os.path.dirname(self.last_json_path)
        else:
            folder = os.getcwd()
        folder = os.path.abspath(folder or ".")

        self._log(f"Opening report folder: {folder}", "info")
        if not self._open_with_os(folder):
            messagebox.showinfo("Report Folder", f"Your reports are saved in:\n{folder}")


def main():
    ctk.set_appearance_mode("light")
    ctk.set_default_color_theme("blue")
    app = AuditorGUI()
    app.mainloop()


if __name__ == "__main__":
    main()
