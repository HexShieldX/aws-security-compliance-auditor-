"""
models.py - Core data structures for findings and scan results.
"""

from dataclasses import dataclass, field, asdict
from typing import List, Dict, Optional, Any
import datetime


@dataclass
class Finding:
    check_id: str            # stable id, e.g. "s3_public_access_block" -> used for compliance lookup
    service: str              # "IAM", "S3", "EC2", "CloudTrail", "GuardDuty", "Config"
    severity: str              # CRITICAL / HIGH / MEDIUM / LOW / INFO / PASS
    message: str
    detail: str = ""
    resource: str = ""
    resource_id: str = ""
    region: str = "global"
    remediation: str = ""
    business_risk: str = ""
    iso27001: List[str] = field(default_factory=list)
    soc2: List[str] = field(default_factory=list)
    nist: List[str] = field(default_factory=list)
    timestamp: str = field(default_factory=lambda: datetime.datetime.now(datetime.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z")

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)


@dataclass
class ScanResult:
    account_id: str
    scan_time: str
    regions_scanned: List[str] = field(default_factory=list)
    findings: List[Finding] = field(default_factory=list)
    errors: List[Dict[str, str]] = field(default_factory=list)   # access-denied / API errors, surfaced not hidden
    total_checks: int = 0

    @property
    def actionable_findings(self) -> List[Finding]:
        """Findings that represent an actual problem (excludes PASS/INFO)."""
        return [f for f in self.findings if f.severity not in ("PASS", "INFO")]

    def severity_counts(self) -> Dict[str, int]:
        counts = {"CRITICAL": 0, "HIGH": 0, "MEDIUM": 0, "LOW": 0, "PASS": 0, "INFO": 0}
        for f in self.findings:
            counts[f.severity] = counts.get(f.severity, 0) + 1
        return counts

    def to_dict(self) -> Dict[str, Any]:
        return {
            "account_id": self.account_id,
            "scan_time": self.scan_time,
            "regions_scanned": self.regions_scanned,
            "total_checks": self.total_checks,
            "findings": [f.to_dict() for f in self.findings],
            "errors": self.errors,
            "severity_counts": self.severity_counts(),
        }
