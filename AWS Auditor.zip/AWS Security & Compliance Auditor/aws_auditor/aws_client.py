"""
aws_client.py - Session and region discovery helpers.
"""

from typing import List
import boto3
from botocore.exceptions import ClientError, NoCredentialsError


class AuditorError(Exception):
    pass


def get_caller_identity(session: boto3.Session) -> dict:
    sts = session.client("sts")
    try:
        return sts.get_caller_identity()
    except NoCredentialsError:
        raise AuditorError(
            "No AWS credentials found. Configure them with 'aws configure', "
            "environment variables, or an instance/role profile."
        )
    except ClientError as e:
        raise AuditorError(f"Could not verify AWS identity: {e}")


def list_enabled_regions(session: boto3.Session, home_region: str = "us-east-1") -> List[str]:
    """
    Returns all regions enabled for this account (not just opted-in-by-default ones).
    Falls back to [home_region] if the describe_regions call fails (e.g. restrictive SCP).
    """
    try:
        ec2 = session.client("ec2", region_name=home_region)
        resp = ec2.describe_regions(AllRegions=False)  # only enabled regions
        regions = sorted(r["RegionName"] for r in resp["Regions"])
        return regions or [home_region]
    except ClientError:
        return [home_region]
