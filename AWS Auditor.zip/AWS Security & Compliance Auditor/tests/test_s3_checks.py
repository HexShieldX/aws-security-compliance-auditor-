import boto3
from moto import mock_aws
from aws_auditor.checks.s3_checks import run_s3_checks


@mock_aws
def test_public_bucket_flagged_critical():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="my-bucket")
    # no public access block configured -> should be flagged CRITICAL

    findings, errors = run_s3_checks(s3)
    pab_findings = [f for f in findings if f.check_id == "s3_public_access"]
    assert len(pab_findings) == 1
    assert pab_findings[0].severity == "CRITICAL"
    assert errors == []


@mock_aws
def test_encrypted_versioned_bucket_passes():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="secure-bucket")
    s3.put_public_access_block(
        Bucket="secure-bucket",
        PublicAccessBlockConfiguration={
            "BlockPublicAcls": True, "IgnorePublicAcls": True,
            "BlockPublicPolicy": True, "RestrictPublicBuckets": True,
        },
    )
    s3.put_bucket_encryption(
        Bucket="secure-bucket",
        ServerSideEncryptionConfiguration={
            "Rules": [{"ApplyServerSideEncryptionByDefault": {"SSEAlgorithm": "AES256"}}]
        },
    )
    s3.put_bucket_versioning(Bucket="secure-bucket", VersioningConfiguration={"Status": "Enabled"})

    findings, errors = run_s3_checks(s3)
    by_id = {f.check_id: f.severity for f in findings if f.resource == "secure-bucket"}

    assert by_id["s3_public_access"] == "PASS"
    assert by_id["s3_encryption_disabled"] == "PASS"
    assert by_id["s3_versioning_disabled"] == "PASS"
    assert errors == []


@mock_aws
def test_compliance_controls_attached_to_finding():
    s3 = boto3.client("s3", region_name="us-east-1")
    s3.create_bucket(Bucket="my-bucket")

    findings, _ = run_s3_checks(s3)
    pab_finding = next(f for f in findings if f.check_id == "s3_public_access")
    # compliance mapping must not be empty for a real check
    assert pab_finding.iso27001
    assert pab_finding.soc2
    assert pab_finding.nist
