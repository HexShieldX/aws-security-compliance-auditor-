import boto3
from moto import mock_aws
from aws_auditor.checks.ec2_checks import run_ec2_checks


@mock_aws
def test_ssh_open_to_world_flagged_critical():
    ec2 = boto3.client("ec2", region_name="us-east-1")
    vpc = ec2.create_vpc(CidrBlock="10.0.0.0/16")["Vpc"]
    sg = ec2.create_security_group(GroupName="web-servers", Description="test", VpcId=vpc["VpcId"])
    ec2.authorize_security_group_ingress(
        GroupId=sg["GroupId"],
        IpPermissions=[{
            "IpProtocol": "tcp", "FromPort": 22, "ToPort": 22,
            "IpRanges": [{"CidrIp": "0.0.0.0/0"}],
        }],
    )

    findings, errors = run_ec2_checks(ec2, "us-east-1")
    ssh_findings = [f for f in findings if f.check_id == "sg_dangerous_port_open"]
    assert len(ssh_findings) == 1
    assert ssh_findings[0].severity == "CRITICAL"
    assert "SSH" in ssh_findings[0].message
    assert errors == []


@mock_aws
def test_internal_only_rule_not_flagged():
    ec2 = boto3.client("ec2", region_name="us-east-1")
    vpc = ec2.create_vpc(CidrBlock="10.0.0.0/16")["Vpc"]
    sg = ec2.create_security_group(GroupName="internal-api", Description="test", VpcId=vpc["VpcId"])
    ec2.authorize_security_group_ingress(
        GroupId=sg["GroupId"],
        IpPermissions=[{
            "IpProtocol": "tcp", "FromPort": 8080, "ToPort": 8080,
            "IpRanges": [{"CidrIp": "10.0.0.0/8"}],
        }],
    )

    findings, errors = run_ec2_checks(ec2, "us-east-1")
    flagged = [f for f in findings if f.severity in ("CRITICAL", "HIGH", "MEDIUM") and f.resource == sg["GroupId"]]
    assert flagged == []
    assert errors == []
