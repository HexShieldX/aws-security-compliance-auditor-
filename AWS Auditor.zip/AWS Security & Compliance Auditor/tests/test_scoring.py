from aws_auditor.models import Finding
from aws_auditor.scoring import compute_risk, compliance_score


def _finding(severity):
    return Finding(check_id="x", service="TEST", severity=severity, message="m")


def test_all_pass_gives_minimal_risk_and_full_score():
    findings = [_finding("PASS") for _ in range(5)]
    level, pct, total, maxs = compute_risk(findings)
    # PASS-only findings excluded from actionable set upstream in real usage,
    # but compute_risk itself should still return 0 score for pass-only input
    assert total == 0


def test_critical_dominates_risk_level():
    findings = [_finding("CRITICAL") for _ in range(3)]
    level, pct, total, maxs = compute_risk(findings)
    assert level == "CRITICAL RISK"
    assert pct == 100.0


def test_compliance_score_ignores_info():
    findings = [_finding("PASS"), _finding("PASS"), _finding("CRITICAL"), _finding("INFO")]
    score = compliance_score(findings)
    # 2 pass out of 3 scored (INFO excluded) = 66.67 -> rounds to 67
    assert score == 67
