"""
test_iam_checks.py - Verifies IAM checks, especially that pagination actually
works past the first page (this was the exact bug we're fixing).
"""

import boto3
from moto import mock_aws
from aws_auditor.checks.iam_checks import run_iam_checks


@mock_aws
def test_root_mfa_and_password_policy():
    iam = boto3.client("iam", region_name="us-east-1")
    iam.update_account_password_policy(MinimumPasswordLength=8)

    findings, errors = run_iam_checks(iam)
    ids = {f.check_id: f.severity for f in findings}

    assert ids["root_mfa_disabled"] == "CRITICAL"
    assert ids["password_policy_length"] == "HIGH"
    assert errors == []


@mock_aws
def test_pagination_finds_users_beyond_first_page():
    """
    This is the regression test for the exact bug in the original tool:
    list_users() without a paginator silently truncates past ~100 users.
    We create more than one page's worth (moto's default max is 100) worth
    of signal by creating enough users that pagination MUST be exercised,
    and assert every single one is represented in findings.
    """
    iam = boto3.client("iam", region_name="us-east-1")
    usernames = [f"user-{i:03d}" for i in range(150)]
    for name in usernames:
        iam.create_user(UserName=name)

    findings, errors = run_iam_checks(iam)
    mfa_findings = [f for f in findings if f.check_id == "user_mfa_disabled"]

    checked_usernames = {f.resource for f in mfa_findings}
    assert checked_usernames == set(usernames), (
        f"Expected all {len(usernames)} users to be checked, "
        f"only found {len(checked_usernames)} - pagination is broken."
    )
    assert errors == []


@mock_aws
def test_stale_access_key_flagged():
    iam = boto3.client("iam", region_name="us-east-1")
    iam.create_user(UserName="old-key-user")
    iam.create_access_key(UserName="old-key-user")

    findings, _ = run_iam_checks(iam)
    key_findings = [f for f in findings if f.check_id == "access_key_stale" and f.resource == "old-key-user"]
    # moto creates the key "now", so it should currently pass (age 0 days)
    assert any(f.severity == "PASS" for f in key_findings)
