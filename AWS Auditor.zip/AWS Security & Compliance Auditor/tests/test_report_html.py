from aws_auditor.models import Finding, ScanResult
from aws_auditor.report_html import generate_html_report


def test_malicious_resource_name_is_escaped():
    """
    Regression test: a bucket/IAM/SG name is attacker-influenceable in some
    scenarios (e.g. an attacker with limited create permissions naming a
    resource maliciously). The report must not execute it as HTML/JS when
    opened in a browser.
    """
    evil_name = '<script>alert(1)</script>'
    finding = Finding(
        check_id="s3_public_access",
        service="S3",
        severity="CRITICAL",
        message=f"Bucket '{evil_name}' is public",
        detail=evil_name,
        resource=evil_name,
    )
    result = ScanResult(account_id="123", scan_time="now", findings=[finding], total_checks=1)

    html_out = generate_html_report(result)

    assert "<script>alert(1)</script>" not in html_out
    assert "&lt;script&gt;" in html_out
