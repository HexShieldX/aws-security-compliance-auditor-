#!/usr/bin/env python3
"""
run_gui.py - Launcher for the AWS Security & Compliance Auditor desktop GUI.

This does not contain any application logic itself; it just starts the
CustomTkinter GUI defined in aws_auditor/gui.py, which in turn reuses the
existing scanning, scoring, and reporting modules unchanged.

Usage:
    python run_gui.py

The CLI remains fully available and unaffected, e.g.:
    python -m aws_auditor.cli --mock
    python -m aws_auditor.cli --region us-east-1 --format both
"""

from aws_auditor.gui import main

if __name__ == "__main__":
    main()
