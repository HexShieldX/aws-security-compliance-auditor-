# AWS Security & Compliance Auditor

A real, live-AWS security auditor that checks IAM, S3, EC2 security groups,
CloudTrail, and GuardDuty against common misconfigurations, maps findings to
ISO 27001 / SOC 2 / NIST CSF controls, and produces an HTML + JSON evidence
report.

## What changed from the earlier version (and why it matters)

| Issue before | Fix |
|---|---|
| Hardcoded to `us-east-1` only | Auto-discovers and scans **every enabled region** for region-scoped services (EC2 SGs, CloudTrail, GuardDuty) |
| `list_users()`, `list_buckets()`, etc. called without pagination — silently dropped data past the first page | Every listable API call goes through a **paginator**; regression-tested with 150 mock IAM users |
| Two separate, inconsistent tools (mock scanner + live scanner) with different report formats | **Single package**, one data model, one report generator, `--mock` flag for demo mode |
| Branded as "AI-Powered" / "AI Risk Scoring Engine" for a plain weighted sum | Renamed honestly to a **deterministic weighted risk score** — see `scoring.py` docstring |
| No compliance framework mapping in the live scanner | Every check maps to ISO 27001 / SOC 2 / NIST CSF via `compliance.py` |
| Findings inserted into HTML unescaped | All dynamic values pass through `html.escape()` — regression-tested |
| AWS API errors silently folded into vague "INFO" log lines | Errors are captured **separately** (`ScanResult.errors`) and surfaced in their own report section, not hidden |
| No tests | 12 tests using `moto` (mocked AWS), including the pagination regression test |
| No CI/CD hook | `--fail-on CRITICAL` exits non-zero so it can gate a pipeline |
| Ran with whatever IAM permissions you had | `policies/read_only_audit_policy.json` — least-privilege policy to attach instead of AdministratorAccess |

## Multi-account scanning (desktop GUI)

The desktop GUI (`python -m aws_auditor.gui` or `run_gui.py`) can now scan
multiple AWS accounts in one run:

- It auto-detects every profile in `~/.aws/config` and `~/.aws/credentials`
  and lists them as checkboxes (Select All / Clear / Refresh Profiles).
- Leave the list empty and Live Scan behaves exactly as before (your default
  credential chain, single account, reports written to
  `aws_audit_report.{html,json,pdf}` in the working directory).
- Check one or more profiles and Live Scan scans them **sequentially**, each
  with its own `boto3.Session(profile_name=...)` (never the default session),
  updating the dashboard after every account completes.
- Each account gets its own report: `reports/<profile>/aws_audit_report.{html,json,pdf}`.
  When more than one profile is scanned, a cross-account
  `reports/combined_summary.{html,json,pdf}` is also generated, and the
  dashboard switches to a combined view.
- No new dependencies: profile discovery uses only the standard library's
  `configparser` (see `aws_auditor/aws_profiles.py`); the aggregation layer
  lives in `aws_auditor/multi_account.py` and reuses the existing
  `report_html.py` / `report_json.py` / `gui_pdf.py` writers untouched.

## Install

```bash
pip install -r requirements.txt
```

## Run

```bash
# Demo, no AWS credentials needed
python -m aws_auditor.cli --mock

# Live scan, auto-discovers all enabled regions
python -m aws_auditor.cli

# Live scan restricted to specific regions
python -m aws_auditor.cli --regions us-east-1,eu-west-1

# CI/CD gate: fail the build if anything CRITICAL is found
python -m aws_auditor.cli --fail-on CRITICAL

# JSON output for downstream tooling
python -m aws_auditor.cli --format json --output evidence.json
```

## Required AWS permissions

Attach `policies/read_only_audit_policy.json` to whatever role/user runs this.
It's read-only (`Get*`, `List*`, `Describe*` only) — this tool never modifies
your account.

## Test

```bash
pytest tests/ -v
```

## Honest limitations (still true after this rewrite)

- The S3 client is created once (S3 is a global-ish API), not per bucket
  region. AWS transparently redirects most bucket metadata calls across
  regions, but opt-in regions that aren't enabled on the account can still
  fail — those show up in the `errors` section rather than being silently
  skipped, but aren't auto-retried in a different region.

- Checks are a curated set (~20), not the hundreds a mature CSPM (Prowler,
  ScoutSuite, Security Hub) covers. Good for prioritizing the highest-impact
  misconfigurations, not a substitute for a full CSPM.
- No persistence/history layer — each run is a point-in-time snapshot. If you
  want trend-over-time, pipe the JSON output into a database yourself.
- This is a prioritization tool, not a certified audit. The report says so in
  the footer on purpose.
